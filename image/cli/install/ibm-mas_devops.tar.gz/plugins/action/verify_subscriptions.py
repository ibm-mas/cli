#!/usr/bin/env python3

from ansible_collections.kubernetes.core.plugins.module_utils.k8s.client import get_api_client

from ansible.plugins.action import ActionBase
from ansible.errors import AnsibleError
from ansible.utils.display import Display

import time

class ActionModule(ActionBase):
    def run(self, tmp=None, task_vars=None):
        super(ActionModule, self).run(tmp, task_vars)
        display = Display()

        # Initialize DynamicClient and grab the task args
        host = self._task.args.get('host', None)
        api_key = self._task.args.get('api_key', None)

        dynClient = get_api_client(api_key=api_key, host=host)
        retries = self._task.args['retries']
        delay = self._task.args['delay']

        display.v(f"Checking Subscriptions are up to date ({retries} retries with a {delay} second delay)")
        subscriptions = dynClient.resources.get(api_version="operators.coreos.com/v1alpha1", kind='Subscription')

        allSubscriptionsAtLatest = False
        attempts = 0
        while attempts < retries and not allSubscriptionsAtLatest:
          subs = subscriptions.get()
          attempts += 1
          allSubscriptionsAtLatestThisLoop = True
          atLatest = []
          notAtLatest = []

          for subscription in subs.items:
            state = subscription.status.state
            installPlanApproval = getattr(subscription.spec, 'installPlanApproval', 'Automatic')
            display.v(f"* {subscription.metadata.namespace}/{subscription.metadata.name} = {state} (approval: {installPlanApproval})")
            
            # Accept both "AtLatestKnown" and "UpgradePending" with Manual approval as valid states
            # UpgradePending with Manual approval means the operator is installed at the desired version
            # but newer versions are available that require manual approval
            isValidState = (state == "AtLatestKnown" or
                           (state == "UpgradePending" and installPlanApproval == "Manual"))
            
            if not isValidState:
              allSubscriptionsAtLatestThisLoop = False
              notAtLatest.append(f"{subscription.metadata.namespace}/{subscription.metadata.name} = {state} (approval: {installPlanApproval})")
            else:
              atLatest.append(f"{subscription.metadata.namespace}/{subscription.metadata.name} = {state} (approval: {installPlanApproval})")

          if allSubscriptionsAtLatestThisLoop:
            allSubscriptionsAtLatest = True
          else:
            display.v(f"Delaying {delay} seconds before next check")
            time.sleep(delay)

        if allSubscriptionsAtLatest:
          return dict(
            message="All Subscriptions are at the latest known operator version",
            failed=False,
            changed=False,
            atLatest=atLatest,
            notAtLatest=notAtLatest
          )
        else:
          raise AnsibleError(f"Error: One or more subscriptions did not update to the latest known operator version")
