import yaml
import re
import copy
import datetime


def private_vlan(vlans):
  """
    filter: private_vlan
    author: Caio Pereira <caiofcp@br.ibm.com>
    version_added: 0.1
    short_description: Provides private vlan id
    description:
        - This lookup returns a private vlan id to be used to create roks cluster
        - It matches both datacenters and pods, e.g., defining your private/public vlans as 
          bcr01a.dal10 and fcr01a.dal10 since it's matching on 01a.
    options:
      _terms:
        description: list of Vlans
        required: True
    notes:
      - limited error handling, will not handle unexpected data currently
  """
  private_vlan = None
  public_vlan_router = [x['properties']['primary_router'] for x in vlans if x['type'] == 'public'][0][3:6]
  for vlan in vlans:
      if vlan['type'] == 'private' and vlan['properties']['primary_router'][3:6] == public_vlan_router:
        private_vlan = vlan['id']
  return private_vlan


def public_vlan(vlans):
  """
      filter: public_vlan
      author: Caio Pereira <caiofcp@br.ibm.com>
      version_added: 0.1
      short_description: Provides public vlan id
      description:
          - This lookup returns a public vlan id to be used to create roks cluster
      options:
        _terms:
          description: list of Vlans
          required: True
      notes:
        - limited error handling, will not handle unexpected data currently
  """
  public_vlan = [x['id'] for x in vlans if x['type'] == 'public'][0]
  return public_vlan


def appws_components(components):
  """
      filter: appws_components
      author: Andrew Whitfield <whitfiea@uk.ibm.com>
      version_added: 0.1
      short_description: Returns components in yaml form
      description:
          - This filter takes the key=value pairs, seperated by commas, for components to be installed into an app workspace
          and returns them in yaml form.
      options:
        components:
          description: key=value pairs of components, seperated by commas, to install into an application workspace.
          required: True
  """
  if components is None or components == '' or components == '{}':
    return None
  else:
    # Take base=latest,health=latest and make {'base': {'version': 'latest'},'health': {'version': 'latest'}}
    split_components = components.strip().split(',')
    components_yaml = {}
    for component in split_components:
      split_component = component.split('=')
      components_yaml[split_component[0]] = {'version': split_component[1]}

    return components_yaml


def db2_overwrite_config(components):
  """
      filter: db2_overwrite_config
      author: André Marcelino <andrercm@br.ibm.com>
      version_added: 0.1
      short_description: Returns db2 config in yaml form
      description:
          - This filter takes the key=value pairs, seperated by semicolon, for db2 custom config to be used in db2ucluster
          and returns them in yaml form.
      options:
        components:
          description: key=value pairs of components, seperated by semicolon, to install into an application workspace.
          required: True
  """
  if components is None or components == '' or components == '{}':
    return None
  else:
    # Take INSTANCE_MEMORY=AUTOMATIC and make {'dbmConfig': {'INSTANCE_MEMORY': 'AUTOMATIC'}}
    split_components = components.strip().split(';')
    components_yaml = {}

    for component in split_components:
      split_component = component.split('=')
      components_yaml[split_component[0]] = split_component[1]

    return components_yaml


def string2dict(_string = None):
  """
  filter: string2dict
    _string
    author: Richard Acree <acree@us.ibm.com>
    version_added: 0.1
    short_description: This method creates dict from a string
    description:
      - This method creates dict from the user passed string
    options:
      _string:
        description: user passed string, format to be passed x=y,foo=bar,hello=world
        required: True
    notes:
      - limited error handling, will not handle unexpected data
  """
  _dict = {}
  if _string and _string != 'None':
    try:
      _list = _string.strip().split(',')
      for _item in _list:
        _item = _item.split("=")
        _dict[ _item[0] ] = _item[1]
    except:
      print("Failed to parse parameter: "+_string)
      _dict = {}
  return _dict


def getAnnotations(annotations = None):
  """
  filter: getAnnotations
    annotations
    author: Padmanabhan Kosalaram <pakosal1@in.ibm.com>
    version_added: 0.1
    short_description: This method creates annotation dict
    description:
        - This method creates annotation dict from the user passed annotation
    options:
      _annotations:
        description: user passed annotation, format to be passed x=y,foo=bar,hello=world
        required: True
    notes:
      - limited error handling, will not handle unexpected data currently
  """
  annotation_dict =	{}
  if annotations:
    try:
        annotation_list = annotations.strip().split(',')
        for annotation in annotation_list:
            annotation = annotation.split("=")
            annotation_dict[ annotation[0] ] = annotation[1]
    except:
        print("Annotation block processing failed, set the annotation_dict blank")
        annotation_dict =	{}
  return annotation_dict


def addAnnotationBlock(cr_definition,annotation_block = None):
  """
  filter: addAnnotationBlock
    cr_definition
    annotation_block
    author: Padmanabhan Kosalaram <pakosal1@in.ibm.com>
    version_added: 0.1
    short_description: Appened annotation block  to CR definition
    description:
        - This method Appened annotation block  to CR definition
    options:
      _cr_definition:
        description: CR definition
        required: True
      _annotation_block:
        description: annotation block to add to the CR User
        required: True
    notes:
      - limited error handling, will not handle unexpected data currently
  """
  print('#--------------------')
  print('cr_definition before adding annotation ::: \n' +cr_definition)

  if annotation_block:
    print('#--------------------')
    print('annotation_block ::: \n' +annotation_block)

    try:
        cr_definition = re.sub('(metadata:)', annotation_block, cr_definition, 1)
    except:
        print("Annotation block replace failed. cr_definition not updated with annotation block")

    print('#--------------------')
    print('cr_definition after adding annotation ::: \n' + cr_definition)

  return cr_definition


def getResourceNames(resourceList):
  """
    filter: getResourceNames
    author: David Parker <parkerda@uk.ibm.com>
    version_added: 10.0
    short_description: Return a list of resource names
    description:
        - This filter returns a list of resource names
    options:
      _resourceList:
        description: list of resources
        required: True
    notes:
      - limited error handling, will not handle unexpected data currently
  """
  resourceNames = []
  for resource in resourceList["resources"]:
    resourceNames.append(resource['metadata']['name'])
  return resourceNames


def getWSLProjectId(wslProjectLookup, wslProjectName):
  """
    filter: getWSLProjectId
    author: Alexandre Quinteiro <alefq@br.ibm.com>
    version_added: 11.0
    short_description: ---
    description:
        - This filter the id of the analytics project that has a name equals to wslProjectName
    options:
      _wslProjectLookup:
        description: list of analytics project objects
        required: True
      _wslProjectName:
        description: name of analytics project we are looking for
        required: True
    notes:
      - limited error handling, will not handle unexpected data currently
  """
  for wslProject in wslProjectLookup:
    if wslProject['entity']['name'] == wslProjectName:
      return wslProject['metadata']['guid']
  # Project not found
  return ""


def setManagePVC(data, mountPath, pvcName, pvcSize, storageClassName, accessMode, volumeName = None):
  """
    filter: setManagePVC
    author: André Marcelino <andrercm@br.ibm.com>
    version_added: 13.0
    short_description: ---
    description:
        - This builds the yaml structure to set Manage persistent volume
    options:
      data:
        description: list of existing Manage Persistent Volumes
        required: True
      mountPath:
        description: Persistent Volumes mount path
        required: True
      mountPath:
        description: Persistent Volumes Claim name
        required: True
      storageClassName:
        description: Persistent Volumes Claim Storage Class name
        required: True
      volumeName:
        description: Persistent Volume name associated to the PVC
        required: True
    notes:
      - limited error handling, will not handle unexpected data currently
  """
  pvc_list = []

  persistentVolumes = {
    "accessModes": [accessMode],
    "mountPath": mountPath,
    "pvcName": pvcName,
    "size": pvcSize,
    "storageClassName": storageClassName,
    "volumeName": volumeName
  }
  if not volumeName:
    del persistentVolumes['volumeName']
  data.append(persistentVolumes)
  for pvc in data:
    pvc_list.append(pvc)
  return pvc_list


def setManageBirtProperties(data, rptRoute, rptServerBundleName):
  sb_list = []
  rpt_bundle = {
    "bundleType": "report",
    "isDefault": False,
    "isMobileTarget": False,
    "isUserSyncTarget": False,
    "name": rptServerBundleName,
    "replica": 1,
    "routeSubDomain": rptServerBundleName
  }

  hasRpt = [True for x in data if x['bundleType'] == 'report']
  if len(hasRpt) == 0:
    data.append(rpt_bundle)
  for sb in data:
    disablequeuemanager = 0 if sb['bundleType'] == 'report' else 1
    if 'bundleLevelProperties' in sb:
      if 'mxe.report.birt.viewerurl' not in sb['bundleLevelProperties'] and 'mxe.report.birt.disablequeuemanager' not in sb['bundleLevelProperties']:
        sb['bundleLevelProperties']+=f"mxe.report.birt.viewerurl={rptRoute}  mxe.report.birt.disablequeuemanager={disablequeuemanager}"
    else:
      sb['bundleLevelProperties']=f"mxe.report.birt.viewerurl={rptRoute}  mxe.report.birt.disablequeuemanager={disablequeuemanager}"
    sb_list.append(sb)
  return sb_list


def setManageDoclinksProperties(data, doclinkPath01, bucketName, accessKey, secretAccesskey, bucketEndpoint):
  sb_list = []
  for sb in data:
    if 'bundleLevelProperties' in sb:
      if 'mxe.doclink.doctypes.topLevelPaths' not in sb['bundleLevelProperties'] and 'mxe.doclink.doctypes.defpath' not in sb['bundleLevelProperties'] and 'mxe.doclink.path01' not in sb['bundleLevelProperties'] and 'mxe.doclink.securedAttachment' not in sb['bundleLevelProperties']:
        sb['bundleLevelProperties']+=f"\nmxe.doclink.doctypes.topLevelPaths=cos:doclinks\nmxe.doclink.doctypes.defpath=cos:doclinks/default\nmxe.doclink.path01=cos:doclinks={doclinkPath01}\nmxe.doclink.securedAttachment=true\nmxe.cosbucketname={bucketName}\nmxe.cosaccesskey={accessKey}\nmxe.cossecretkey={secretAccesskey}\nmxe.cosendpointuri={bucketEndpoint}\nmxe.attachmentstorage=com.ibm.tivoli.maximo.oslc.provider.COSAttachmentStorage"
    else:
      sb['bundleLevelProperties']=f"mxe.doclink.doctypes.topLevelPaths=cos:doclinks\nmxe.doclink.doctypes.defpath=cos:doclinks/default\nmxe.doclink.path01=cos:doclinks={doclinkPath01}\nmxe.doclink.securedAttachment=true\nmxe.cosbucketname={bucketName}\nmxe.cosaccesskey={accessKey}\nmxe.cossecretkey={secretAccesskey}\nmxe.cosendpointuri={bucketEndpoint}\nmxe.attachmentstorage=com.ibm.tivoli.maximo.oslc.provider.COSAttachmentStorage"
    sb_list.append(sb)
  return sb_list


def setManageFsDoclinksProperties(data, manage_url):
  sb_list = []
  for sb in data:
    if 'bundleLevelProperties' in sb:
      if 'mxe.doclink.doctypes.topLevelPaths' not in sb['bundleLevelProperties'] and 'mxe.doclink.doctypes.defpath' not in sb['bundleLevelProperties'] and 'mxe.doclink.path01' not in sb['bundleLevelProperties'] and 'mxe.doclink.securedAttachment' not in sb['bundleLevelProperties']:
        sb['bundleLevelProperties']+=f"\nmxe.doclink.doctypes.topLevelPaths=/DOCLINKS\nmxe.doclink.doctypes.defpath=/DOCLINKS/default\nmxe.doclink.path01=/DOCLINKS=https://{manage_url}/maximo/oslc/doclinks\nmxe.doclink.securedAttachment=true\nmxe.report.AttachDoc.validateURL=0\nmxe.attachmentstorage=null"
    else:
      sb['bundleLevelProperties']=   f"mxe.doclink.doctypes.topLevelPaths=/DOCLINKS\nmxe.doclink.doctypes.defpath=/DOCLINKS/default\nmxe.doclink.path01=/DOCLINKS=https://{manage_url}/maximo/oslc/doclinks\nmxe.doclink.securedAttachment=true\nmxe.report.AttachDoc.validateURL=0\nmxe.attachmentstorage=null"
    sb_list.append(sb)
  return sb_list


def _setSystemProperties(data, meaweb_value, oslc_rest_value, webapp_value, rest_webapp_value):

  sb_list = []

  for sb in data:
    if 'bundleLevelProperties' in sb:
      if 'mxe.int.webappurl' not in sb['bundleLevelProperties'] and 'mxe.oslc.restwebappurl' not in sb['bundleLevelProperties'] and 'mxe.oslc.webappurl' not in sb['bundleLevelProperties'] and 'mxe.rest.webappurl' not in sb['bundleLevelProperties']:
        sb['bundleLevelProperties']+=f"  mxe.int.webappurl={meaweb_value}  mxe.oslc.restwebappurl={oslc_rest_value}  mxe.oslc.webappurl={webapp_value}  mxe.rest.webappurl={rest_webapp_value}"
    else:
      sb['bundleLevelProperties']=f"mxe.int.webappurl={meaweb_value}  mxe.oslc.restwebappurl={oslc_rest_value}  mxe.oslc.webappurl={webapp_value}  mxe.rest.webappurl={rest_webapp_value}"
    sb_list.append(sb)
  return sb_list


def format_pre_version_with_plus(data):
  """
  Versions in format 9.0.0-pre.stable-3757 cannot be used to compare with the version
  reconciled by suite operator, which is in format 9.0.0-pre.stable+3757. This function is to
  format version to make it comparable (replacing last "-" by "+")
  """
  if "pre" not in data or data.count("-") < 2:
    return data
  return data[::-1].replace("-", "+", 1)[::-1]


def format_pre_version_without_buildid(data):
  """
  Versions in format 9.0.0-pre.stable-3757 cannot be used to compare with the version
  reconciled by application operators, which is in format 9.0.0-pre.stable+3757. This function is to
  format version to make it comparable (removing build id part at the end)
  """
  if "pre" not in data or data.count("-") < 2:
    return data
  return data[:data.rfind("-")]

def format_pre_version_with_buildid(data):
  """
  Versions in format 9.0.0-pre.stable-3757 cannot be used to compare with the version
  reconciled by application operators, which is in format 9.0.0-pre.stable+3757. This function is to
  format version to make it comparable
  """
  if "pre" not in data or data.count("-") < 2:
    return data
  build_id_idx = data.rfind('-')
  return f"{data[:build_id_idx]}{(data[build_id_idx:]).replace('-', '+')}"

def get_db2_instance_name(binding_scope, mas_instance_id, mas_workspace_id, mas_application_id):
  if binding_scope == "":
    return ""
  # Only system and workspace-application are possible values here as per CLI
  jdbc_instance_names = {
    "system": f'mas-{mas_instance_id}-system',
    "workspace-application": f'mas-{mas_instance_id}-{mas_workspace_id}-{mas_application_id}'
  }
  return jdbc_instance_names[binding_scope]

def get_ecr_repositories(image_mirror_output):
  """
    filter: get_ecr_repositories
    author: Terence Quinn <quinnt@us.ibm.com>
    version_added: 0.1
    short_description: Get the names of ECR repositories relevant to a mirror command
    description:
        - Parse the output of oc image mirror --dry-run=true command for repository names. The
          list of repository names will be used to create all the required repositories in ECR
          before actually performing the mirror. This is needed for AWS ECR only.
    options:
      image_mirror_output:
        description: Output of the oc image mirror --dry-run=true command
        required: True
    notes:
      - limited error handling, will not handle unexpected data currently
  """
  # marker to indicate summary of images from oc image mirror command
  phase_found = False
  repositories = []
  for line in image_mirror_output:
    line = line.strip()
    # once we find a line starting with phase - start parsing repositories names
    if line.startswith('phase '):
      phase_found = True
      continue
    if line == "":
      phase_found = False
      continue
    if phase_found:
      # parse out the repository name
      if len(line.split()) > 1:
        repo_to_add = line.split()[1]
        repositories.append(repo_to_add)
  return repositories

def is_channel_upgrade_path_valid(current: str, target: str, valid_paths: dict) -> bool:
  """
    Checks if a given current channel version can be upgraded to a target channel version.
    :current: The current channel version.
    :target: The target channel version to upgrade to.
    :valid_paths: A dictionary of supported upgrade paths. See ibm/mas_devops/common_vars/compatibility_matrix.yml.
    :return: True if the upgrade path is supported, False otherwise.
  """
  valid = False
  if not target:
    print('Error: no target upgrade channel provided')
  if current not in valid_paths.keys():
      print(f'Current channel {current} is not supported for upgrade')
  elif target:
      allowed_targets = valid_paths[current]
      if isinstance(allowed_targets, str):
          if target != allowed_targets:
              print(f'Upgrading from channel {current} to {target} is not supported')
          else:
              valid = True
      elif isinstance(allowed_targets, list):
          if target not in allowed_targets:
              print(f'Upgrading from channel {current} to {target} is not supported')
          else:
              valid = True
      else:
          print(f'Error: channel upgrade compatibility matrix is incorrectly defined')
  return valid

def remove_dict_keys(data: dict, keys: list[str], deep_copy: bool = True) -> dict:
  """
    Deletes keys from a dictionary. This has an advantage over Ansible's ansible.utils.remove_keys filter
    in that nested keys are given explicitly in dot notation, for example 'a.b.c'.
    :data: The input dictionary.
    :keys: A list of key strings in dot notation, e.g. ['a.b', 'c.d.e'].
    :deep_copy: Set to False to modify the input dictionary in-place, otherwise a copy will be modified.
    :return: The dictionary with keys removed.
  """
  if deep_copy:
    data = copy.deepcopy(data)
  for key in keys:
    parts = key.split('.')
    ref = 'data'
    for part in parts:
      ref += f'["{part}"]'
    try:
      exec(f'del {ref}')
    except KeyError as ex:
      print(f'Could not delete key from dictionary: {ex}')
  return data

def is_operator_upgraded_by_version(cr_reconciled_version: str, opcon_version: str, sub_installed_version: str) -> bool:
  """
    Checks if an operator was upgraded successfully by comparing versions. Typically we just compare the version reported as
    reconciled in the operator's custom resource with the OperatorCondition, however, this poses a problem for certain images
    that are not tagged with a build number but the build number is used in other places within its bundle. For example, an
    upgraded operator might have the CR reconciled version as "9.2.0-pre.1450" (derived from its image tag) but the version
    from the OperatorCondition resource is "9.2.0-pre.1450-5075" which includes the build number. In this case where they
    don't match we do our best effort by also checking the version reported as installed in the Subscription.
    :cr_reconciled_version: Version number from the "versions.reconciled" field in the CR.
    :opcon_version: Version derived from the operator's OperatorCondition.
    :sub_installed_version: Version derived from the Subscription's "status.installedCSV" field.
    :return: True if the operator was successfully upgraded (at least by checking various versions)
  """
  print(f'{cr_reconciled_version} --- {opcon_version} --- {sub_installed_version}')
  upgraded = False
  opcon_version = opcon_version.replace('+', '-')
  prefix = f'{cr_reconciled_version}-'
  if cr_reconciled_version == opcon_version:
    upgraded = True
  elif opcon_version.startswith(prefix) and sub_installed_version.startswith(prefix) and (opcon_version == sub_installed_version):
      upgraded = True
  return upgraded

def get_default_upgrade_channel(current: str, valid_paths: dict) -> str:
  """
    Gets the default target upgrade channel if the user has not supplied one. 
    :current: The current channel version.
    :valid_paths: A dictionary of supported upgrade paths. See ibm/mas_devops/common_vars/compatibility_matrix.yml.
    :return: The default target upgrade channel.
  """
  default = None
  allowed_targets = valid_paths[current]
  if isinstance(allowed_targets, str):
      default = allowed_targets
  elif isinstance(allowed_targets, list):
      default = allowed_targets[0]
  else:
      print(f'Error: channel upgrade compatibility matrix is incorrectly defined')
  return default


def set_storage_classes_names(storage_list: list, storage_class_name_rwo: str, storage_class_name_rwx: str):
  """
  Iterate through the storage_list list and set the storage_class_name for each storage item based on the access mode.
  Expects data to be
  storage:
  - name: meta
    spec:
      accessModes:
      - ReadWriteMany
      resources:
        requests:
          storage: 20Gi
      storageClassName: nfs-client
    type: create
  - name: backup
    spec:
      accessModes:
      - ReadWriteOnce
      resources:
        requests:
          storage: 20Gi
      storageClassName: nfs-client
    type: create
  """

  for storage_item in storage_list:
    if 'spec' in storage_item and 'accessModes' in storage_item['spec'] and 'storageClassName' in storage_item['spec']: 
      if storage_item['spec']['accessModes'][0] == 'ReadWriteMany':
        storage_item['spec']['storageClassName'] = storage_class_name_rwx
      else:
        storage_item['spec']['storageClassName'] = storage_class_name_rwo
  return storage_list

def override_manage_persistent_volumes(volumes_list: list, storage_class_name_rwo: str, storage_class_name_rwx: str):
  """
  Iterate through the volumes_list list and set the storage_class_name for each storage item based on the access mode.
  Expects data to be
  storage:
  - pvcName: manage-imagestitching
    accessModes:
      - ReadWriteMany
    size: 20Gi
    storageClassName: nfs-client
  - pvcName: manage-2
    accessModes:
      - ReadWriteMany
    size: 20Gi
    storageClassName: nfs-client
  """

  for volume_item in volumes_list:
    if 'accessModes' in volume_item and 'storageClassName' in volume_item:
      if volume_item['accessModes'][0] == 'ReadWriteMany':
        volume_item['storageClassName'] = storage_class_name_rwx
      else:
        volume_item['storageClassName'] = storage_class_name_rwo
  return volumes_list


class FilterModule(object):
  def filters(self):
    return {
      'private_vlan': private_vlan,
      'public_vlan': public_vlan,
      'appws_components': appws_components,
      'addAnnotationBlock': addAnnotationBlock,
      'db2_overwrite_config': db2_overwrite_config,
      'string2dict': string2dict,
      'getAnnotations': getAnnotations,
      'getResourceNames': getResourceNames,
      'getWSLProjectId': getWSLProjectId,
      'setManagePVC': setManagePVC,
      'setManageBirtProperties': setManageBirtProperties,
      'setManageDoclinksProperties': setManageDoclinksProperties,
      'setManageFsDoclinksProperties': setManageFsDoclinksProperties,
      'setSystemProperties': _setSystemProperties,
      'format_pre_version_with_plus': format_pre_version_with_plus,
      'format_pre_version_without_buildid': format_pre_version_without_buildid,
      'format_pre_version_with_buildid': format_pre_version_with_buildid,
      'get_db2_instance_name': get_db2_instance_name,
      'get_ecr_repositories': get_ecr_repositories,
      'is_channel_upgrade_path_valid': is_channel_upgrade_path_valid,
      'remove_dict_keys': remove_dict_keys,
      'is_operator_upgraded_by_version': is_operator_upgraded_by_version,
      'get_default_upgrade_channel': get_default_upgrade_channel,
      'get_default_upgrade_channel': get_default_upgrade_channel,
      'set_storage_classes_names': set_storage_classes_names,
      'override_manage_persistent_volumes': override_manage_persistent_volumes
    }
