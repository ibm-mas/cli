from datetime import datetime
from elasticsearch import Elasticsearch
import os
from pprint import pprint

client = Elasticsearch("https://localhost:9200/", basic_auth=(os.getenv("ES_USERNAME"), os.getenv("ES_PASSWORD")), verify_certs=False)

print()
print("Users")
users = client.security.get_user()
for userName in users:
  print(userName)
print()

print("Roles")
roles = client.security.get_role()
for roleName in roles:
  print(roleName)
exit(1)

print(client.cluster.health())
client.cluster.reroute()
print(client.cluster.health())

client.indices.put_settings(settings={"number_of_replicas":0}, index="*")

exit(1)
indices = client.indices.get(index="*")

for index in indices:
  print(index)
  pprint(indices[index])
  exit(1)
