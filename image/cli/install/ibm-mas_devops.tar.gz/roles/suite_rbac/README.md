# suite_rbac Role

This role applies RBAC (Role-Based Access Control) resources for **ALL MAS operators** during installation based on the selected permission mode.

## Key Features

- **Auto-Discovery**: Automatically discovers all operators in the RBAC directory
- **Multi-Operator Support**: Applies RBAC for ibm-mas, ibm-mas-manage, ibm-mas-iot, and all other operators
- **No Hardcoded Paths**: Uses dynamic file discovery for maximum flexibility
- **Future-Proof**: New operators and RBAC files are automatically handled

## Permission Modes

### 1. cluster (default)
- CLI applies **ClusterRoles** for ALL operators
- Provides full cluster-wide permissions
- Required for full MAS functionality including app lifecycle management

### 2. nonEssential
- CLI applies **non-essential namespace-scoped Roles** for ALL operators
- Restricts permissions to specific namespaces
- Limited app lifecycle management (within pre-created namespaces)
- Suitable for restricted environments

### 3. essential
- CLI applies **NO RBAC** (operators handle essential roles themselves)
- Operators create essential roles automatically during installation
- Minimal permissions
- No app lifecycle management via MAS Admin UI

## RBAC Responsibility

| RBAC Type | Stored In | Applied By | Used In Mode |
|-----------|-----------|------------|--------------|
| **ClusterRoles** | pre-install repo | CLI (this role) | cluster |
| **Non-essential Roles** | pre-install repo | CLI (this role) | nonEssential |
| **Essential Roles** | pre-install repo | Operators themselves | essential (and all modes) |

**Important**: Essential roles are stored in pre-install for operators to copy during installation. The CLI does NOT apply essential roles.

## Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `mas_permission_mode` | Permission mode (cluster/nonEssential/essential) | `cluster` |
| `mas_instance_id` | MAS instance ID | Required |
| `rbac_files_dir` | Location of RBAC files in CLI image | `/opt/app-root/rbac` |
| `discovered_operators` | List of operators (auto-populated) | `[]` |

## RBAC File Structure

The role uses operator-based structure from pre-install repository:

```
/opt/app-root/rbac/operators/
├── ibm-mas/rbac/
│   ├── clusterroles/              ← CLI applies in cluster mode
│   │   ├── clusterrole-coreapi.yaml
│   │   └── clusterrole-entitymgr-suite.yaml
│   └── roles/
│       ├── essential/             ← Operators copy & apply (NOT CLI)
│       │   ├── role-cert-manager.yaml
│       │   └── role-appId-coreapi.yaml
│       └── non-essential/         ← CLI applies in nonEssential mode
│           ├── role-openshift-marketplace.yaml
│           └── role-cert-manager-coreapi.yaml
├── ibm-mas-manage/rbac/
│   ├── clusterroles/
│   └── roles/
│       ├── essential/
│       └── non-essential/
├── ibm-mas-iot/rbac/
├── ibm-mas-monitor/rbac/
└── [all other operators...]
```

## Usage

### In Tekton Pipeline
```yaml
- name: suite-rbac
  taskRef:
    name: mas-devops-suite-rbac
  params:
    - name: mas_instance_id
      value: $(params.mas_instance_id)
    - name: mas_permission_mode
      value: $(params.mas_permission_mode)
```

### Standalone
```bash
ansible-playbook playbook.yml -e mas_instance_id=inst1 -e mas_permission_mode=cluster
```

## How It Works

1. **Discover Operators**: Scans `/opt/app-root/rbac/operators/` to find all available operators
2. **Loop Through Operators**: For each discovered operator:
   - Determine RBAC path: `/opt/app-root/rbac/operators/<operator-name>/rbac/`
   - Apply RBAC based on permission mode:
     - **cluster**: Apply ClusterRoles from `clusterroles/` directory
     - **nonEssential**: Apply non-essential Roles from `roles/non-essential/` directory
     - **essential**: Do nothing (operators will create essential roles)
3. **Template Processing**: All RBAC files are processed as Jinja2 templates with variables like `{{ mas_instance_id }}`

## Auto-Discovery Benefits

The role automatically discovers:
- **All operators** in the RBAC directory (ibm-mas, ibm-mas-manage, ibm-mas-iot, etc.)
- **All RBAC files** within each operator's directory structure
- **New operators** added to pre-install repository
- **New RBAC files** added to existing operators

This means:
- ✅ No hardcoded file paths
- ✅ No code changes when adding new operators
- ✅ No code changes when adding new RBAC files
- ✅ Works for any operator structure
- ✅ Minimal maintenance required

## Example Output

```
TASK [Discover all available operators in RBAC directory]
ok: [localhost]

TASK [Debug - Discovered operators]
ok: [localhost] => {
    "msg": [
        "Operators Directory: /opt/app-root/rbac/operators",
        "Discovered Operators: ibm-mas, ibm-mas-manage, ibm-mas-iot, ibm-mas-monitor, ibm-mas-predict",
        "Total Operators: 5"
    ]
}

TASK [Apply RBAC for each discovered operator] (item=ibm-mas)
  → Processing: ibm-mas
  → Permission Mode: cluster
  → Applied 2 ClusterRoles
ok: [localhost]

TASK [Apply RBAC for each discovered operator] (item=ibm-mas-manage)
  → Processing: ibm-mas-manage
  → Permission Mode: cluster
  → Applied 1 ClusterRole
ok: [localhost]

... (continues for all operators)
```

## Error Handling

- Namespace-scoped Roles use `ignore_errors: true` because some target namespaces may not exist yet
- ClusterRoles fail if they cannot be applied
- Missing RBAC directories for specific operators are logged but don't fail the role
- If no operators are discovered, the role fails with a clear error message

## Adding New Operators

To add RBAC for a new operator:

1. Add RBAC files to pre-install repository:
   ```
   pre-install/maximo-operator-catalog/operators/ibm-mas-newapp/rbac/
   ├── clusterroles/
   │   └── clusterrole-newapp.yaml
   └── roles/
       ├── essential/
       │   └── role-newapp-essential.yaml  (operators will copy this)
       └── non-essential/
           └── role-newapp-nonessential.yaml
   ```

2. Rebuild CLI image (RBAC files auto-copied)

3. Run installation - new operator RBAC automatically applied!

No code changes needed! 🎉

## Dependencies
- RBAC files must be present in the CLI image at `/opt/app-root/rbac/operators/`
- Pre-install repository RBAC files copied during CLI build
- kubernetes.core collection

## License
EPL-2.0

## Author Information
IBM Maximo Application Suite Development Team