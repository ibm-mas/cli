"""
Unit tests for filter plugins.
"""

# Made with Bob
