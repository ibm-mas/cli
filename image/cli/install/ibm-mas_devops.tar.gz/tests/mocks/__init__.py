"""Mock helper modules for MAS DevOps tests."""

# Made with Bob
