# -----------------------------------------------------------
# Licensed Materials - Property of IBM
# 5737-M66, 5900-AAA
# (C) Copyright IBM Corp. 2021 All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication, or disclosure
# restricted by GSA ADP Schedule Contract with IBM Corp.
# -----------------------------------------------------------
import json
import re
from subprocess import PIPE, Popen, TimeoutExpired
import threading
import requests
import os

class RunCmdResult(object):
    def __init__(self, returnCode, output, error):
        self.rc = returnCode
        self.out = output
        self.err = error

    def successful(self):
        return self.rc == 0

    def failed(self):
        return self.rc != 0

def runCmd(cmdArray, timeout=630):
    """
    Run a command on the local host.  This drives all the helm operations,
    as there is no python Helm client available.
    # Parameters
    cmdArray (list<string>): Command to execute
    timeout (int): How long to allow for the command to complete
    # Returns
    [int, string, string]: `returnCode`, `stdOut`, `stdErr`
    """

    lock = threading.Lock()

    with lock:
        p = Popen(cmdArray, stdin=PIPE, stdout=PIPE, stderr=PIPE, bufsize=-1)
        try:
            output, error = p.communicate(timeout=timeout)
            return RunCmdResult(p.returncode, output, error)
        except TimeoutExpired as e:
            return RunCmdResult(127, 'TimeoutExpired', str(e))

def getDigest(image):
  """
    filter: getDigest
    author: Jonah Luckett <jonah.luckett@ibm.com>
    short_description: Fetches digest of repo passed in
    description:
        - This lookup uses skopeo to fetch the digest for an imaged passed in which will be passed to the CLI
    options:
      image:
        description: image to inspect (e.g: docker-na-public.artifactory.swg-devops.com/wiotp-docker-local/mas-devops/fvt-iot:latest)
        required: True
    notes:
      - Will return an empty string if met with failure when looking up the digest
  """
  artifactory_username=os.getenv("FVT_ARTIFACTORY_USERNAME")
  artifactory_token=os.getenv("FVT_ARTIFACTORY_TOKEN")
  credentials = f"{artifactory_username}:{artifactory_token}"
  cmdArray = [
    "skopeo", "inspect", f"docker://{image}", "--creds", credentials
  ]
  result = runCmd(cmdArray)
  if result.successful():
    resultData = json.loads(result.out)
    return resultData['Digest']
  else:
    return "" 

def identifyLatest(repo):
  """
    filter: identifyLatest
    author: Jonah Luckett <jonah.luckett@ibm.com>
    short_description: Identifies latest version of repo passed in
    description:
        - This lookup returns a the specific release version equivalent of the latest tag for the required repo
    options:
      repo:
        description: repo to check
        required: True
    notes:
      - Will return latest if met with failure when looking up the version
  """

  headers = {
      'Authorization': 'token {}'.format(os.getenv('GITHUB_TOKEN')),
  }
  url = 'https://github.ibm.com/api/v3/repos/{}/releases/latest'.format(repo)
  response = requests.request("GET", url, headers=headers)
  try:
    version = response.json()['tag_name']
  except:
    version = "latest"
    # no need to change anything if the response can't find a tag

  return version

class FilterModule(object):
  def filters(self):
    return {
      'identifyLatest': identifyLatest,
      'getDigest': getDigest
    }
