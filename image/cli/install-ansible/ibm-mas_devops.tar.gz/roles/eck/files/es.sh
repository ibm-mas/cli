#!/bin/bash

ES_HOST=localhost:9200

function getShardsInState(){
  state=$1
  curl -s -k -u $ES_USERNAME:$ES_PASSWORD -XGET https://$ES_HOST/_cat/shards?format=json | jq ".[] | select(.state==\"$state\")"
}

getShardsInState "UNASSIGNED"
