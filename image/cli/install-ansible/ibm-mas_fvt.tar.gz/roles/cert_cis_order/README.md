# cert_cis_order

`cert_cis_order` is a tool to simplify ordering of public certificates via IBM Cloud Secret Manager. It uses a pre-defined resource created in MAS Development account called `fvt-secret-mgr`, under `cicd` resource group. This tool is already configured with one certificate authority and one dns provider, respectively Let's Encrypt and Cloud Internet Services (CIS).

------
## Role Variables

### cis_apikey
IBM Cloud API Key with write access in the Internet Services provided by `cis_crn`

- Required
- Environment Variable: `CIS_APIKEY`

### cis_subdomain
Subdomain of `ibmmasfvt.com`, usually is the FVT_ENVIRONMENT / MAS_INSTANCE_ID as used by fvt environments, resulting in `{{cis_subdomain}}.ibmmasfvt.com`

- Required
- Environment Variable: `CIS_SUBDOMAIN`

### certificates_config_dir
File system path where the certificates will be downloaded as expected by MAS

- Required
- Environment Variable: `CERTIFICATES_CONFIG_DIR`

###  cis_crn
CRN value that identifies the CIS instance that will be used to hold CNAMES that wll be resolved to cluster ingress. The CNAMES added in this CIS instance will also be used by Secrets Manager's public certificate odering process.

- Required
- Environment Variable: `CIS_CRN`
- Default Value: `crn:v1:bluemix:public:internet-svcs:global:a/02fd888448c1415baa2bcd65684e4db3:4c691f74-6c6a-4048-89a6-db022241df9b::` (CRN of `fvt-cis` service, configured in fvt-secret-mgr as DNS Provider under `fvt-manucert-dns`configuration)

### mas_workspace_id
MAS workspace id. Required as workspace is part of URL of all the applicatins, necessary in the certification process

- Required
- Environment Variable: `MAS_WORKSPACE_ID`
- Default Value: `masdev` (used in FVT environments)

### cis_proxy
When set to `True`, enable CNAMES to be protected by CIS security rules. Default of `False` is used in fvt environments.

- Optional
- Environment Variable: `CIS_PROXY`
- Default Value: `False`

### ibmcloud_endpoint
IBM CLoud endpoint.

- Optional
- Environment Variable: `IBMCLOUD_ENDPOINT`
- Default Value: `https://cloud.ibm.com`

### ibmcloud_apikey
API Key used to access Secret Manager service in IBM Cloud. When not informed, it uses the required `CIS_APIKEY` value. It is expected this API Key has a write access in the secret manager informed by `secret_service_endpoint`

- Optional
- Environment Variable: `IBMCLOUD_APIKEY`
- Default Value: same as `CIS_APIKEY`

### secret_service_endpoint
Endpoint used by ibmcloud command line invoke api calls against to.

- Optional
- Environment Variable: `SECRET_SERVICE_ENDPOINT`
- Default Value: same as `https://f5c5653b-4e30-4e20-bd49-b457554fa7e9.us-south.secrets-manager.appdomain.cloud` (endpoing of existing `fvt-secret-mgr` instance created in MAS Development accoung under `cicd` resource group)

### secret_ca_name
Name of the CA configuration created in Secrets Manager service. Use `fvt-manucert-ca` as default which is already configured to order Let's Encrypt certificates

- Optional
- Environment Variable: `SECRET_CA_NAME`
- Default Value: `fvt-manucert-ca`

### secret_dns_name
Name of the DNS configuration created in Secrets Manager service. Use `fvt-manucert-dns` as default which is already configured to use CIS as DNS provider

- Optional
- Environment Variable: `SECRET_DNS_NAME`
- Default Value: `fvt-manucert-dns`

------
## Behind the scenes


### Part 1: Adding CNAMES in CIS

After guarantee all the required variables are informed, this role invokes `ibm.mas_devops.cis_dns_entries` to create or update CNAMES in the CIS instance specifided by `cis_crn`, using `cis_apikey`, `cis_subdomain`, `cis_proxy` and the wildcard dns entries pre-defined [here](https://github.ibm.com/maximoappsuite/ansible-fvt/blob/certorderdoc/ansible/ibm/mas_fvt/roles/cert_cis_order/templates/dnsentries.yml.j2#L1). CNAMES will be temporarily resolved to `localhost.ibm.com` as we do not have yet OCP Ingress to be used here (it will be added by mas_install pipeline when it invokes the same `ibm.mas_devops.cis_dns_entries`)

### Part 2: Order certificates

This process will be repeated by each application:
- Check if public certiticate secret already exist in Secret Manager service (using this name convention: `{{ cis_subdomain }}-cis-letsenc-{{ app_id }}`)
- Create a public certificate if secret does not exist
- Obtain the certificate created: certificate itself, intermediate and private key
- Download the certs and create files as expected by MAS into `certificates_config_dir` folder. The folder structure created in `certificates_config_dir` is

```
{{ certificates_config_dir }}
   |
   | ---- {{ cis_subdomain }}
       |
       | ---- {{ app_id }}
           |
           |--- ca.crt
           |--- tls.crt
           |--- tls.key
```
- Note: If we already have certificates created for that application, folder will be deleted and recreated, so the certificates will allbe replaced

### Part 3: Validating and Making certs available

This part is not automated till now but it is recommented to confirm certificate CN is good before we make it available to be used by fvt environments ([lessons learned](https://github.ibm.com/maximoappsuite/tracker-fvt/issues/98#issuecomment-58186047))

Having `openssl` command availale in your Terminal:

```
openssl x509 -in tls.crt -text -noout
```

Make sure certs have CN according to the certificate you are analysing. In this example, it was a iot cerfificate for fvtstable subdomain:

```
(...)
Subject: CN=iot.fvtstable.ibmmasfvt.com (for cert)
(...)
Subject CN=iot.fvtstable.ibmmasfvt.com (for intermediate)
(...)
```

## How to use

Having ansble command lines installed, go to `ansible/ibm/mas_fvt`, inside ansible-fvt and:

```
ansible-galaxy collection build --force
ansible-galaxy collection installd --force --ignore-certs
```

... to install the collection. Then:

```
export FVT_ENVIRONMENT=fvtcore
export IBMCLOUD_APIKEY=<add yours>
export DNS_PROVIDER=cis
export CIS_CRN="crn:v1:bluemix:public:internet-svcs:global:a/02fd888448c1415baa2bcd65684e4db3:4c691f74-6c6a-4048-89a6-db022241df9b::"
export CIS_SUBDOMAIN=$FVT_ENVIRONMENT
export CIS_APIKEY=$IBMCLOUD_APIKEY
export MAS_DOMAIN=$FVT_ENVIRONMENT.ibmmasfvt.com
export ROLE_NAME=cert_cis_order
export MAS_WORKSPACE_ID=masdev
export CERTIFICATES_CONFIG_DIR=<replcae with a local folder>

ansible-playbook ibm.mas_fvt.run_role
```

... to run the playbook. At the end, check your `certificates_config_dir` folder and the certificates will be there. The structure of folders created there is same as expected by [devops-config](https://github.ibm.com/maximoappsuite/devops-configs/tree/master/certs), from where the certificates will be obtained when used in FVT environments. Replace them accordingly in master branch wait for the next FVT run.
