ocp_disable_updates
===================

This role will disable automatic updates in the cluster.  It's use is not recommended.

Example Playbook
----------------

```yaml
- hosts: localhost
  roles:
    - ibm.mas_devops.ocp_disable_updates
```


License
-------

EPL-2.0
