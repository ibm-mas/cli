# mongodb

This role currently supports provisioning of mongodb in four different providers:
 - community
 - aws (documentdb)
 - ibm
 - atlas (MongoDB Atlas)
**Important Notice**
Support for the **atlas (MongoDB Atlas)** provider is currently in **Proof of Concept (PoC)** stage. It is intended for **testing and development purposes only** and **is not recommended for production deployments** at this time.

If the selected provider is `community` then the [MongoDB Community Kubernetes Operator](https://github.com/mongodb/mongodb-kubernetes-operator) will be configured and deployed into the specified namespace. By default a three member MongoDB replica set will be created.  The cluster will bind six PVCs, these provide persistence for the data and system logs across the three nodes.  Currently there is no support built-in for customizing the cluster beyond this configuration.

!!! tip
    The role will generate a yaml file containing the definition of a Secret and MongoCfg resource that can be used to configure the deployed instance as the MAS system MongoDb.

    This file can be directly applied using `oc apply -f $MAS_CONFIG_DIR/mongocfg-mongoce-system.yaml` or used in conjunction with the [suite_config](suite_config.md) role.


## Prerequisites

### General Prerequisites
To run this role with providers as `ibm` or `aws` you must have already installed the [AWS CLI](https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html).
Also, you need to have AWS user credentials configured via `aws configure` command or simply export `AWS_ACCESS_KEY_ID` and `AWS_SECRET_ACCESS_KEY` environment variables with your corresponding AWS username credentials prior running this role when provider is either `ibm` or `aws` or `atlas`.

To run the `docdb_secret_rotate` MONGODB_ACTION when the provider is `aws` you must have already installed the [Mongo Shell](https://www.mongodb.com/docs/mongodb-shell/install/).

This role will install a GrafanaDashboard used for monitoring the MongoDB instance when the provided is `community` and you have run the [grafana role](https://ibm-mas.github.io/ansible-devops/roles/grafana/) previously. If you did not run the [grafana role](https://ibm-mas.github.io/ansible-devops/roles/grafana/) then the GrafanaDashboard won't be installed.

### MongoDB Atlas Prerequisites
When using `mongodb_provider=atlas`, you must complete the following prerequisites:

#### 1. Create AWS Secrets Manager Secret (Required)
Create a secret in AWS Secrets Manager to store your Atlas API credentials. The secret must follow this naming convention:

**Secret Name**: `<atlas_account_id>/mongodb-atlas`

Where `<atlas_account_id>` is your AWS account ID (e.g., `123456789012/mongodb-atlas`).

**Secret Format**: The secret must contain a JSON object with these exact field names:
```json
{
  "mongodb_atlas_api_pub_key": "your-atlas-public-key",
  "mongodb_atlas_api_pri_key": "your-atlas-private-key"
}
```

**How to create the secret**:
```bash
# Replace 123456789012 with your AWS account ID
export ACCOUNT_ID="123456789012"
export SECRET_NAME="${ACCOUNT_ID}/mongodb-atlas"

# Create the secret with Atlas API credentials
aws secretsmanager create-secret \
  --name "${SECRET_NAME}" \
  --description "MongoDB Atlas API credentials for account ${ACCOUNT_ID}" \
  --secret-string '{"mongodb_atlas_api_pub_key":"YOUR_PUBLIC_KEY","mongodb_atlas_api_pri_key":"YOUR_PRIVATE_KEY"}' \
  --region us-east-1

# Or update an existing secret
aws secretsmanager put-secret-value \
  --secret-id "${SECRET_NAME}" \
  --secret-string '{"mongodb_atlas_api_pub_key":"YOUR_PUBLIC_KEY","mongodb_atlas_api_pri_key":"YOUR_PRIVATE_KEY"}' \
  --region us-east-1
```

**Note**: The field names must be exactly `mongodb_atlas_api_pub_key` and `mongodb_atlas_api_pri_key` as shown above.

#### 2. Add IP Address to Atlas API Access List
Add your IP address to the Atlas API Access List before running this role:

1. Log in to [MongoDB Atlas Console](https://cloud.mongodb.com)
2. Navigate to your Organization → Access Manager → API Keys
3. Select your API key
4. Click "Edit" and add your current IP address to the Access List

**Note**: The role cannot automatically add IP addresses to the Atlas API Access List. If your IP is not whitelisted, API calls will fail with `403 IP_ADDRESS_NOT_ON_ACCESS_LIST` error.


## Role Variables - General

### Common Variables

#### mas_instance_id
Unique identifier for the MAS instance that will use this MongoDB deployment.

- **Optional**
- Environment Variable: `MAS_INSTANCE_ID`
- Default Value: None

**Purpose**: Identifies which MAS instance this MongoDB configuration targets. Used to generate the MongoCfg resource that connects MAS to the MongoDB instance.

**When to use**:
- Set when you want to automatically generate MongoCfg for MAS integration
- Must be set together with `mas_config_dir` for MongoCfg generation
- Leave unset if manually managing MongoDB configuration for MAS

**Valid values**: Lowercase alphanumeric string, 3-12 characters (e.g., `prod`, `dev`, `inst1`)

**Impact**: When set with `mas_config_dir`, generates a MongoCfg YAML file at `$MAS_CONFIG_DIR/mongocfg-mongoce-system.yaml`. Without this, no MAS configuration file is created.

**Related variables**: Must be set together with `mas_config_dir` for MongoCfg generation.

#### mas_config_dir
Local directory path where the generated MongoCfg resource file will be saved.

- **Optional**
- Environment Variable: `MAS_CONFIG_DIR`
- Default Value: None

**Purpose**: Specifies where to save the MongoCfg YAML file that configures MAS to connect to this MongoDB instance. This file can be applied manually or used with the `suite_config` role for automated MAS configuration.

**When to use**:
- Set when you want to automatically generate MongoCfg for MAS integration
- Must be set together with `mas_instance_id` for MongoCfg generation
- Use the same directory across multiple dependency roles (mongodb, db2, sls) to collect all configurations
- Leave unset if manually managing MongoDB configuration for MAS

**Valid values**: Any valid local filesystem path (e.g., `/home/user/masconfig`, `~/masconfig`, `./config`)

**Impact**: When set with `mas_instance_id`, creates file `mongocfg-mongoce-system.yaml` in this directory. The file contains Secret and MongoCfg resources ready to apply to MAS.

**Related variables**:
- Must be set together with `mas_instance_id` for MongoCfg generation
- Used by `suite_config` role to apply configurations

#### mongodb_provider
Selects which MongoDB deployment option to use for MAS database requirements.

- **Optional**
- Environment Variable: `MONGODB_PROVIDER`
- Default Value: `community`

**Purpose**: Determines the MongoDB infrastructure provider, which affects deployment architecture, management approach, operational requirements, and cost model. Each provider offers different trade-offs between control, convenience, and cost.

**When to use**:
- Use `community` for self-managed deployments on OpenShift with full control
- Use `ibm` for managed IBM Cloud Databases for MongoDB service
- Use `aws` for managed AWS DocumentDB service (MongoDB-compatible)
- Use `atlas` for managed MongoDB Atlas service (fully managed cloud database)
- Consider operational expertise, cloud platform, and management preferences

**Valid values**:
- `community` - MongoDB Community Edition Operator (self-managed on OpenShift)
- `ibm` - IBM Cloud Databases for MongoDB (managed service)
- `aws` - AWS DocumentDB (managed service, MongoDB-compatible)
- `atlas` - MongoDB Atlas

**Impact**:
- `community`: Requires cluster storage, manual backup management, and operational overhead
- `ibm`: Requires IBM Cloud account, API key, and incurs IBM Cloud service charges
- `aws`: Requires AWS account, VPC configuration, and incurs AWS service charges
- `atlas`: Requires AWS account, AWS IAM permissions, and incurs AWS service charges

**Related variables**:
- When `community`: Requires `mongodb_storage_class` and related storage/resource variables
- When `ibm`: Requires `ibmcloud_apikey`, `ibm_mongo_region`, `ibm_mongo_resourcegroup`
- When `aws`: Requires `aws_access_key_id`, `aws_secret_access_key`, `vpc_id`, `docdb_*` variables
- When `atlas`: Requires `aws_access_key_id`, `aws_secret_access_key`, `atlas_account_id` (secret name is automatically derived as `<atlas_account_id>/mongodb-atlas`)
- Affects which `mongodb_action` values are supported

**Note**: Provider cannot be changed after initial deployment. Migration between providers requires backup and restore procedures.

#### mongodb_action
Specifies which operation to perform on the MongoDB instance.

- **Optional**
- Environment Variable: `MONGODB_ACTION`
- Default Value: `install`

**Purpose**: Controls what action the role executes against the MongoDB instance. Different providers support different sets of actions based on their capabilities and management model.

**When to use**:
- Use `install` for initial deployment or updates
- Use `uninstall` to remove MongoDB instance (use with caution)
- Use `backup` to create MongoDB backups (community/ibm only)
- Use `restore` to restore from backup (community/ibm/atlas only)
- Use `docdb_secret_rotate` to rotate DocumentDB credentials (aws only)
- Use `destroy-data` to delete all data from MongoDB (aws only)
- Use `create-mongo-service-credentials` to generate service credentials (ibm only)

**Valid values** (provider-specific):
- **community**: `install`, `uninstall`, `backup`, `backup-database`, `restore`, `restore-database`
- **aws**: `install`, `uninstall`, `docdb_secret_rotate`, `destroy-data`
- **ibm**: `install`, `uninstall`, `backup`, `restore`, `create-mongo-service-credentials`
- **atlas**: `install`, `uninstall`, `restore`, `restore-database`

**Impact**: The action determines what the role will do. Destructive actions like `uninstall` and `destroy-data` will permanently delete data. Backup/restore actions require additional variables to be set.

**Related variables**:
- `mongodb_provider` determines which actions are available
- AWS secret rotation requires `docdb_*` credential variables

**Note**: Always backup data before performing destructive operations. Some actions are irreversible.

### CE Operator Variables

#### mongodb_namespace
OpenShift namespace where the MongoDB Community Operator and MongoDB cluster will be deployed.

- **Optional**
- Environment Variable: `MONGODB_NAMESPACE`
- Default Value: `mongoce`

**Purpose**: Defines the Kubernetes namespace for MongoDB resources, providing isolation and organization for the MongoDB deployment within the cluster.

**When to use**:
- Use default `mongoce` for standard deployments
- Change only if you need multiple MongoDB instances or have namespace naming requirements
- Ensure namespace doesn't conflict with existing deployments

**Valid values**: Any valid Kubernetes namespace name (lowercase alphanumeric and hyphens)

**Impact**: All MongoDB resources (operator, replica set pods, PVCs, secrets, services) will be created in this namespace. Changing this after deployment requires reinstallation.

**Related variables**: Used in MongoCfg generation to reference MongoDB service endpoints.

#### mongodb_version
Specifies the MongoDB version to deploy.

- **Optional**
- Environment Variable: `MONGODB_VERSION`
- Default Value: Automatically defined by the mongo version specified in the [latest MAS case bundle available](https://github.com/ibm-mas/python-devops/tree/stable/src/mas/devops/data/catalogs)

**Purpose**: Controls which MongoDB version is deployed, ensuring compatibility with MAS requirements and enabling version-specific features. The default aligns with the tested and supported version for your MAS release.

**When to use**:
- Leave as default for standard deployments (recommended)
- Override only when specific version requirements exist
- Use for testing compatibility with newer MongoDB versions
- Never use to downgrade an existing MongoDB instance

**Valid values**: `7.0.12`, `7.0.22`, `7.0.23`, `8.0.13`, `8.0.17`, `8.0.20`  (check MAS compatibility matrix for supported versions)

**Impact**: Determines MongoDB feature set, performance characteristics, and compatibility. Changing versions may require data migration or compatibility testing.

**Related variables**:
- Version upgrades require corresponding `mongodb_v*_upgrade` flags
- Must be compatible with MAS version requirements

**Note**: **Never downgrade MongoDB versions**. Always create scheduled backups before version changes. Use `mongodb_v5_upgrade`, `mongodb_v6_upgrade`, `mongodb_v7_upgrade`, or `mongodb_v8_upgrade` flags when upgrading between major versions.

#### mongodb_override_spec
Forces the role to use environment variables instead of preserving existing MongoDB spec settings.

- **Optional**
- Environment Variable: `MONGODB_OVERRIDE_SPEC`
- Default Value: `false`

**Purpose**: Controls whether the role preserves existing MongoDB configuration during upgrades/reinstalls or applies new values from environment variables. This prevents accidental configuration changes during routine operations.

**When to use**:
- Leave as `false` (default) to preserve existing settings during upgrades
- Set to `true` only when intentionally changing MongoDB configuration
- Use with caution - requires setting all environment variables to match desired state

**Valid values**: `true`, `false`

**Impact**:
- When `false`: Existing CPU, memory, storage, and replica settings are preserved during reinstall/upgrade
- When `true`: All settings are taken from environment variables; unset variables revert to defaults

**Related variables**: When set to `true`, affects these settings:
- `mongodb_cpu_limits`
- `mongodb_mem_limits`
- `mongodb_cpu_requests`
- `mongodb_mem_requests`
- `mongodb_storage_class`
- `mongodb_storage_capacity_data`
- `mongodb_storage_capacity_logs`
- `mongodb_replicas`

**Note**: **Check existing MongoDB installation before enabling**. If environment variables don't match current spec, resources may be reset to defaults, potentially causing disruption. Unknown settings are not preserved.

#### mongodb_storage_class
Name of the Kubernetes storage class for MongoDB persistent volumes.

- **Required** when `mongodb_provider=community`
- Environment Variable: `MONGODB_STORAGE_CLASS`
- Default Value: None

**Purpose**: Specifies which storage class provides persistent volumes for MongoDB data and logs. The storage class determines performance characteristics, availability, and cost of MongoDB storage.

**When to use**:
- Always required for Community Edition deployments
- Choose based on performance requirements (SSD vs HDD)
- Consider backup and snapshot capabilities of the storage class
- Verify storage class exists in your cluster before deployment

**Valid values**: Any valid storage class name in your cluster that supports ReadWriteOnce (RWO) access mode

**Impact**: Affects MongoDB performance, reliability, and cost. Six PVCs will be created (data + logs for each of 3 replicas by default). Storage class cannot be changed after deployment without data migration.

**Related variables**:
- `mongodb_storage_capacity_data` - Size of data PVCs
- `mongodb_storage_capacity_logs` - Size of log PVCs
- `mongodb_replicas` - Number of replica sets (affects total PVC count)

**Note**: Storage class must support ReadWriteOnce (RWO) access mode. Verify with `oc get storageclass` before deployment.

#### mongodb_storage_capacity_data
Size of the persistent volume claim (PVC) for MongoDB data storage on each replica set member.

- **Optional**
- Environment Variable: `MONGODB_STORAGE_CAPACITY_DATA`
- Default Value: `20Gi`

**Purpose**: Determines disk space allocated for storing MongoDB databases, collections, and indexes on each replica. Proper sizing prevents storage exhaustion and ensures adequate space for data growth.

**When to use**:
- Increase from default for production environments with large data volumes
- Increase for environments with high data growth rates
- Use default (20Gi) for development, testing, or small deployments
- Consider backup strategy when sizing (larger volumes take longer to backup)

**Valid values**: Any valid Kubernetes storage size (e.g., `20Gi`, `100Gi`, `500Gi`, `1Ti`)

**Impact**:
- Larger values consume more cluster storage resources
- Cannot be decreased after deployment (PVC expansion only)
- Total storage = this value × number of replicas
- Affects backup and restore duration

**Related variables**:
- `mongodb_replicas`: Total storage = capacity × replicas
- `mongodb_storage_class`: Must support volume expansion if you plan to increase size later
- `mongodb_storage_capacity_logs`: Consider balancing data and log storage

**Note**: PVCs can be expanded but not shrunk. Plan for growth when setting initial size. Monitor storage usage to avoid running out of space.

#### mongodb_storage_capacity_logs
Size of the persistent volume claim (PVC) for MongoDB log storage on each replica set member.

- **Optional**
- Environment Variable: `MONGODB_STORAGE_CAPACITY_LOGS`
- Default Value: `20Gi`

**Purpose**: Determines disk space allocated for MongoDB operational logs on each replica. Logs are essential for troubleshooting, auditing, and monitoring MongoDB operations.

**When to use**:
- Increase for production environments with verbose logging requirements
- Increase if log retention policies require longer history
- Use default (20Gi) for standard deployments
- Consider log rotation and retention policies when sizing

**Valid values**: Any valid Kubernetes storage size (e.g., `10Gi`, `20Gi`, `50Gi`)

**Impact**:
- Larger values consume more cluster storage resources
- Cannot be decreased after deployment (PVC expansion only)
- Total log storage = this value × number of replicas
- Insufficient log space can cause MongoDB operational issues

**Related variables**:
- `mongodb_replicas`: Total log storage = capacity × replicas
- `mongodb_storage_class`: Must support volume expansion
- `mongodb_storage_capacity_data`: Consider balancing data and log storage

**Note**: Monitor log usage and implement log rotation to prevent filling log volumes. PVCs can be expanded but not shrunk.

#### mongodb_cpu_limits
Maximum CPU cores allocated to each MongoDB container.

- **Optional**
- Environment Variable: `MONGODB_CPU_LIMITS`
- Default Value: `1`

**Purpose**: Sets the upper bound on CPU usage for MongoDB containers, preventing any single MongoDB instance from consuming excessive cluster CPU resources.

**When to use**:
- Increase for production workloads with high query volumes
- Increase for large datasets requiring more processing power
- Use default (1 core) for development or light workloads
- Set higher than `mongodb_cpu_requests` to allow burst capacity

**Valid values**: CPU units as decimal (e.g., `0.5`, `1`, `2`, `4`) or millicores (e.g., `500m`, `1000m`, `2000m`)

**Impact**:
- Higher limits allow better performance under load but consume more cluster resources
- Limits prevent MongoDB from starving other workloads of CPU
- Total CPU limit = this value × number of replicas
- Setting too low can cause performance degradation

**Related variables**:
- `mongodb_cpu_requests`: Should be set lower than limits for burst capacity
- `mongodb_replicas`: Total CPU = limits × replicas
- `mongodb_mem_limits`: Balance CPU and memory allocation

**Note**: Ensure cluster has sufficient CPU capacity for all replicas. Monitor actual CPU usage to right-size limits.

#### mongodb_mem_limits
Maximum memory allocated to each MongoDB container.

- **Optional**
- Environment Variable: `MONGODB_MEM_LIMITS`
- Default Value: `1Gi`

**Purpose**: Sets the upper bound on memory usage for MongoDB containers. MongoDB uses memory for caching data and indexes, so adequate memory is critical for performance.

**When to use**:
- Increase significantly for production workloads (4Gi-8Gi recommended)
- Increase for large datasets to improve cache hit rates
- Default (1Gi) is only suitable for development/testing
- Set higher than `mongodb_mem_requests` to allow burst capacity

**Valid values**: Memory size (e.g., `1Gi`, `2Gi`, `4Gi`, `8Gi`, `16Gi`)

**Impact**:
- Higher limits improve performance through better caching
- Limits prevent MongoDB from consuming all cluster memory
- Total memory limit = this value × number of replicas
- Setting too low causes frequent cache evictions and poor performance

**Related variables**:
- `mongodb_mem_requests`: Should be set lower than limits
- `mongodb_replicas`: Total memory = limits × replicas
- `mongodb_cpu_limits`: Balance CPU and memory allocation

**Note**: MongoDB performance heavily depends on available memory. Production deployments typically need 4Gi-8Gi per replica. Monitor memory usage and adjust accordingly.

#### mongodb_cpu_requests
Guaranteed CPU cores reserved for each MongoDB container.

- **Optional**
- Environment Variable: `MONGODB_CPU_REQUESTS`
- Default Value: `500m`

**Purpose**: Defines the minimum CPU resources guaranteed to MongoDB containers. Kubernetes scheduler uses this to place pods on nodes with sufficient available CPU.

**When to use**:
- Increase for production workloads requiring consistent performance
- Set to match expected baseline CPU usage
- Use default (500m) for development or light workloads
- Set lower than `mongodb_cpu_limits` to allow burst capacity

**Valid values**: CPU units as decimal (e.g., `0.5`, `1`, `2`) or millicores (e.g., `500m`, `1000m`, `2000m`)

**Impact**:
- Higher requests guarantee more CPU but may limit pod scheduling if cluster capacity is constrained
- Requests ensure MongoDB has minimum CPU even under cluster load
- Total CPU request = this value × number of replicas
- Affects pod Quality of Service (QoS) class

**Related variables**:
- `mongodb_cpu_limits`: Requests should be lower than limits
- `mongodb_replicas`: Total CPU requests = this value × replicas
- `mongodb_mem_requests`: Balance CPU and memory requests

**Note**: Set requests based on baseline usage, not peak. The difference between requests and limits provides burst capacity.

#### mongodb_mem_requests
Guaranteed memory reserved for each MongoDB container.

- **Optional**
- Environment Variable: `MONGODB_MEM_REQUESTS`
- Default Value: `1Gi`

**Purpose**: Defines the minimum memory resources guaranteed to MongoDB containers. Kubernetes scheduler uses this to place pods on nodes with sufficient available memory.

**When to use**:
- Increase for production workloads (2Gi-4Gi recommended)
- Set to match expected baseline memory usage
- Default (1Gi) is only suitable for development/testing
- Set lower than `mongodb_mem_limits` to allow burst capacity

**Valid values**: Memory size (e.g., `1Gi`, `2Gi`, `4Gi`, `8Gi`)

**Impact**:
- Higher requests guarantee more memory but may limit pod scheduling if cluster capacity is constrained
- Requests ensure MongoDB has minimum memory even under cluster load
- Total memory request = this value × number of replicas
- Affects pod Quality of Service (QoS) class

**Related variables**:
- `mongodb_mem_limits`: Requests should be lower than limits
- `mongodb_replicas`: Total memory requests = this value × replicas
- `mongodb_cpu_requests`: Balance CPU and memory requests

**Note**: MongoDB needs adequate memory for good performance. Production deployments typically need 2Gi-4Gi requests. Set based on baseline usage, not peak.

#### mongodb_replicas
Number of MongoDB replica set members to deploy.

- **Optional**
- Environment Variable: `MONGODB_REPLICAS`
- Default Value: `3`

**Purpose**: Determines the size of the MongoDB replica set, which affects high availability, read scalability, and resource consumption. Replica sets provide data redundancy and automatic failover.

**When to use**:
- Use default (3) for production deployments with high availability requirements
- Set to 1 only for Single Node OpenShift (SNO) clusters or development environments
- Use 5 or more for critical production workloads requiring higher availability
- Odd numbers (1, 3, 5) are recommended for proper election quorum

**Valid values**: Positive integers, typically 1, 3, or 5

**Impact**:
- More replicas = higher availability but more resource consumption
- Each replica requires its own data and log PVCs
- Total resources = (CPU + memory + storage) × replicas
- Affects election behavior and write acknowledgment

**Related variables**:
- `mongodb_storage_capacity_data`: Total data storage = capacity × replicas
- `mongodb_storage_capacity_logs`: Total log storage = capacity × replicas
- `mongodb_cpu_limits` and `mongodb_mem_limits`: Total resources = limits × replicas

**Note**: Set to 1 for SNO clusters. Production deployments should use 3 or more for high availability. Changing replica count after deployment requires careful planning.

#### custom_labels
Comma-separated list of key=value labels to apply to MongoDB resources.

- **Optional**
- Environment Variable: `CUSTOM_LABELS`
- Default Value: None

**Purpose**: Adds Kubernetes labels to MongoDB resources for organization, selection, and filtering. Labels enable resource tracking, cost allocation, and custom automation.

**When to use**:
- Use to add organizational metadata (e.g., `cost-center=engineering`, `environment=production`)
- Use to enable resource tracking and cost allocation
- Use to support custom automation or monitoring tools
- Use to comply with organizational labeling standards

**Valid values**: Comma-separated list of `key=value` pairs (e.g., `env=prod,team=platform,app=mongodb`)

**Impact**: Labels are applied to MongoDB resources and can be used for filtering with `oc get` commands, monitoring queries, and automation scripts. Labels do not affect MongoDB functionality.

**Related variables**: Works alongside Kubernetes resource labels for comprehensive resource management.

#### mongodb_v5_upgrade
Confirmation flag to upgrade MongoDB from version 4.x to version 5.

- **Optional**
- Environment Variable: `MONGODB_V5_UPGRADE`
- Default Value: `false`

**Purpose**: Acts as a safety confirmation to prevent accidental MongoDB major version upgrades. Upgrading MongoDB major versions requires careful planning and testing.

**When to use**:
- Set to `true` only when intentionally upgrading from MongoDB 4.2 or 4.4 to version 5
- Must be explicitly set to perform the upgrade
- Leave as `false` for all other operations

**Valid values**: `true`, `false`

**Impact**: When `true` and `mongodb_version` is set to a 5.x version, triggers MongoDB upgrade from 4.x to 5.x. This is a one-way operation that cannot be reversed without restoring from backup.

**Related variables**:
- `mongodb_version`: Must be set to a 5.x version for upgrade to proceed
- Other upgrade flags: `mongodb_v6_upgrade`, `mongodb_v7_upgrade`, `mongodb_v8_upgrade`

**Note**: **Always backup before upgrading**. Test upgrades in non-production environments first. Review MongoDB 5.0 release notes for breaking changes and new requirements (e.g., AVX instruction set).

#### mongodb_v6_upgrade
Confirmation flag to upgrade MongoDB from version 5 to version 6.

- **Optional**
- Environment Variable: `MONGODB_V6_UPGRADE`
- Default Value: `false`

**Purpose**: Acts as a safety confirmation to prevent accidental MongoDB major version upgrades from version 5 to 6.

**When to use**:
- Set to `true` only when intentionally upgrading from MongoDB 5 to version 6
- Must be explicitly set to perform the upgrade
- Leave as `false` for all other operations

**Valid values**: `true`, `false`

**Impact**: When `true` and `mongodb_version` is set to a 6.x version, triggers MongoDB upgrade from 5.x to 6.x. This is a one-way operation that cannot be reversed without restoring from backup.

**Related variables**:
- `mongodb_version`: Must be set to a 6.x version for upgrade to proceed
- Other upgrade flags: `mongodb_v5_upgrade`, `mongodb_v7_upgrade`, `mongodb_v8_upgrade`

**Note**: **Always backup before upgrading**. Test upgrades in non-production environments first. Review MongoDB 6.0 release notes for breaking changes.

#### mongodb_v7_upgrade
Confirmation flag to upgrade MongoDB from version 6 to version 7.

- **Optional**
- Environment Variable: `MONGODB_V7_UPGRADE`
- Default Value: `false`

**Purpose**: Acts as a safety confirmation to prevent accidental MongoDB major version upgrades from version 6 to 7.

**When to use**:
- Set to `true` only when intentionally upgrading from MongoDB 6 to version 7
- Must be explicitly set to perform the upgrade
- Leave as `false` for all other operations

**Valid values**: `true`, `false`

**Impact**: When `true` and `mongodb_version` is set to a 7.x version, triggers MongoDB upgrade from 6.x to 7.x. This is a one-way operation that cannot be reversed without restoring from backup.

**Related variables**:
- `mongodb_version`: Must be set to a 7.x version for upgrade to proceed
- Other upgrade flags: `mongodb_v5_upgrade`, `mongodb_v6_upgrade`, `mongodb_v8_upgrade`

**Note**: **Always backup before upgrading**. Test upgrades in non-production environments first. Review MongoDB 7.0 release notes for breaking changes.

#### mongodb_v8_upgrade
Confirmation flag to upgrade MongoDB from version 7 to version 8.

- **Optional**
- Environment Variable: `MONGODB_V8_UPGRADE`
- Default Value: `false`

Role Variables - Backup and Restore (CE Operator)
-------------------------------------------------------------------------------

### mongodb_action
For backup and restore operations, set `mongodb_action` to one of the following:
- `backup`: Create a backup of MongoDB databases and instance resources
- `backup-database`: Create a backup of MongoDB databases only
- `restore`: Restore both MongoDB instance resources and databases from a backup (full restore)
- `restore-database`: Restore only MongoDB databases from a backup to an existing instance (database-only restore)

- Environment Variable: `MONGODB_ACTION`
- Default Value: `install`

**Action Details:**
- **backup**: Creates a complete backup including database data and Kubernetes resources (secrets, certificates, CRs)
- **backup-database**: Creates a complete backup including database data only
- **restore**: Performs a full restore by recreating the MongoDB instance from backup resources and then restoring database data
- **restore-database**: Restores only the database data to an already running MongoDB instance without touching instance resources

### mas_backup_dir
**Required for backup/restore operations**. Local directory path where backup files will be stored or read from.

- Environment Variable: `MAS_BACKUP_DIR`
- Default Value: None
- Example: `/tmp/masbr`

### mongodb_backup_version
**Required for restore operations**. The backup version timestamp to restore from. This is automatically generated during backup in the format `YYYYMMDD-HHMMSS`.

- Environment Variable: `MONGODB_BACKUP_VERSION`
- Default Value: YYYYMMDD-HHMMSS
- Example: `20251212-021316`

### mongodb_instance_name
The name of the MongoDB instance to backup.

- Environment Variable: `MONGODB_INSTANCE_NAME`
- Default Value: `mas-mongo-ce`

### override_storageclass
Controls whether to override storage class for the MongoDB instance during restore.
Set to `true` to override the storage class with `MONGODB_STORAGE_CLASS` value or cluster's default storageclass.

- Environment Variable: `OVERRIDE_STORAGECLASS`
- Default Value: `false`

### mas_app_id
Optional. Specific MAS application ID for targeted backup/restore operations.

- Environment Variable: `MAS_APP_ID`
- Default Value: None


Backup and Restore Operations
-------------------------------------------------------------------------------

This section provides comprehensive information about MongoDB backup and restore operations for the Community Edition (CE) operator.

### Action Comparison

| Action | Purpose | Instance Resources | Database Data | Prerequisites | Use Case |
|--------|---------|-------------------|---------------|---------------|----------|
| `backup` | Create backup | Yes | Yes | Running MongoDB instance | Regular backups, disaster recovery preparation |
| `backup-database` | Database-only backup | No | Yes | Running MongoDB instance | Regular backups, disaster recovery preparation |
| `restore` | Full restore | Yes (recreates instance) | Yes | Backup with instance resources | Disaster recovery, cluster migration, complete restoration |
| `restore-database` | Database-only restore | No (preserves existing) | Yes | Running MongoDB instance with matching version | Data recovery, selective restore, testing |

### Backup Process

The MongoDB backup operation creates a backup of your MongoDB instance and databases associated with your MAS instance:

1. **Database Backup**: Uses `mongodump` to export databases with filter `"^(mas|iot|sls|ibm-sls)(_|-)({{ mas_instance_id }}|sls)(_|-)(?!.*monitor$)"` to match databases like `mas-<instance-id>-<app-id>` or `iot-<instance-id>-<app-id>` or `ibm-sls_sls_licensing` or `sls-<instance-id>_sls_licensing`.
2. **Instance Resources** : Backs up Kubernetes resources including:
   - CustomResourceDefinition (CRD)
   - MongoDBCommunity Custom Resource (CR)
   - Secrets (TLS certificates, credentials)
   - Certificate resources
   - Issuer resources
   - Mongodb operator deployment
   - service monitoring
   - grafana dashboards

**Backup Directory Structure:**
```
/tmp/masbr/
└── backup-<YYYYMMDD-HHMMSS>-mongoce/
    ├── data/
    │   ├── mongodump-<YYYYMMDD-HHMMSS>.tar.gz
    │   └── mongodb-info.yaml
    └── resources/
        ├── mongodbcommunitys/
        ├── secrets/
        ├── certificates/
        └── issuers/
        └── {kind}s/
```

### Restore Process

The MongoDB role supports two types of restore operations:

#### 1. Full Restore (`restore` action)
Performs a complete restoration of both the MongoDB instance and its databases:

**Steps:**
1. Validates backup files and required variables
2. Restores the namespace (Project)
3. Restores Secrets and ConfigMaps
4. Restores CustomResourceDefinitions (CRDs)
5. Restores RBAC resources (ServiceAccount, Role, RoleBinding)
6. Configures anyuid permissions for MongoDB service accounts
7. Restores the MongoDB Operator Deployment
8. Waits for MongoDB operator to be ready
9. Restores Certificate Manager resources (Issuer, Certificate)
10. Restores the MongoDBCommunity Custom Resource (Overrides storageclass if flag is set)
11. Waits for MongoDB StatefulSets to be ready
12. Restores ServiceMonitor and GrafanaDashboard resources
13. Restores database data using `mongorestore`

**When to use:**
- Disaster recovery scenarios
- Migrating MongoDB to a new cluster
- Recreating a deleted MongoDB instance
- Setting up a new environment from backup

**Requirements:**
- `mas_instance_id`: MAS instance identifier
- `mas_backup_dir`: Directory containing the backup
- `mongodb_backup_version`: Timestamp of the backup to restore
- `override_storageclass`: Set to `true` to override storage class during instance restore

#### 2. Database-Only Restore (`restore-database` action)
Restores only the database data to an existing MongoDB instance:

**Steps:**
1. Validates backup files and required variables
2. Verifies existing MongoDB installation is running
3. Checks MongoDB version compatibility
4. Restores database data using `mongorestore`

**When to use:**
- Restoring data to an existing MongoDB instance
- Recovering from data corruption without recreating the instance
- Selective database restoration
- Testing data restoration without affecting instance configuration

**Requirements:**
- `mas_instance_id`: MAS instance identifier
- `mas_backup_dir`: Directory containing the backup
- `mongodb_backup_version`: Timestamp of the backup to restore
- `mongodb_namespace`: Namespace where MongoDB is running
- `mongodb_instance_name`: Name of the existing MongoDB instance
- MongoDB instance must already be running and accessible

### Important Considerations

**Version Compatibility:**
- Target MongoDB version must match the backup version exactly
- Version upgrades should be performed separately, not during restore
- The restore process validates version compatibility before proceeding
- For `restore-database` action, the existing MongoDB instance must be running the same version as the backup

**Storage Requirements:**
- Ensure sufficient storage in the backup directory
- Plan for at least 2x the database size for backup storage
- Backup directory structure: `/tmp/masbr/backup-<YYYYMMDD-HHMMSS>-mongoce/`
- Monitor disk space during backup operations

**Security:**
- Backup files contain sensitive data and credentials
- Secure backup directory with appropriate permissions (chmod 700 recommended)
- Consider encrypting backups for long-term storage
- Backup includes TLS certificates and admin credentials
- Restrict access to backup files to authorized personnel only

**Performance:**
- Backup operations may impact MongoDB performance
- Schedule backups during low-usage periods
- Monitor resource utilization during backup/restore
- Large databases may take significant time to backup/restore
- Network bandwidth may affect backup/restore speed

**Restore Action Differences:**
- **`restore` action**: Recreates the entire MongoDB instance from scratch, including all Kubernetes resources and restores database
- **`restore-database` action**: Only restores database data to an existing instance, preserving current configuration

### Backup and Restore Best Practices

1. **Regular Backups**: Schedule automated backups at regular intervals
2. **Test Restores**: Periodically test restore procedures in non-production environments
3. **Monitor Operations**: Implement monitoring and alerting for backup failures
4. **Backup Validation**: Verify backup integrity after completion
5. **Retention Policy**: Implement and document backup retention policies
6. **Disaster Recovery**: Include MongoDB backup/restore in your DR plan

### Backup and Restore Issues

**Backup Failures:**

- **Permission Errors**: Verify backup role and user creation succeeded. Check MongoDB pod logs with `oc logs -n mongoce <pod-name> -c mongod`
- **Disk Space Issues**: Ensure sufficient space in backup directory. Clean up old backups if needed like `/tmp/<mongodb_backup_version>`. Check with `df -h`. 
- **Pod Access Issues**: Verify pod is running and accessible. Check network connectivity to the cluster

**Restore Failures:**

- **Version Mismatch**: Ensure target MongoDB version matches backup version. Deploy correct version before restoring
- **Authentication Errors**: Verify admin credentials are correct. Check MongoDB health status
- **Missing Backup Files**: Verify backup directory path and version. Ensure backup completed successfully
- **Data Inconsistency**: Verify backup integrity. Check restore logs for errors. Consider re-running restore

**General Issues:**

- **Pods Not Starting After Restore**: Check pod events with `oc describe pod -n mongoce <pod-name>`. Verify PVCs are bound. Check resource limits and node capacity
- **Connection Issues**: Verify network policies and service configurations. Check certificate validity

Example Playbooks
-------------------------------------------------------------------------------

### Install (CE Operator)
```yaml
- hosts: localhost
  any_errors_fatal: true
  vars:
    mongodb_storage_class: ibmc-block-gold
    mas_instance_id: masinst1
    mas_config_dir: ~/masconfig
  roles:
    - ibm.mas_devops.mongodb
```

### Backup (CE Operator)
```yaml
- hosts: localhost
  any_errors_fatal: true
  vars:
    mas_instance_id: masinst1
    mas_backup_dir: /tmp/masbr
    mongodb_action: backup
  roles:
    - ibm.mas_devops.mongodb
```

### Backup with Instance Resources (CE Operator)
Create a complete backup including both database data and instance resources (secrets, certificates, issuers).

```yaml
- hosts: localhost
  any_errors_fatal: true
  vars:
    mas_instance_id: masinst1
    mas_backup_dir: /tmp/masbr
    mongodb_action: backup
  roles:
    - ibm.mas_devops.mongodb
```

### Backup Database (CE Operator)
Create a backup of database data.

```yaml
- hosts: localhost
  any_errors_fatal: true
  vars:
    mas_instance_id: masinst1
    mas_backup_dir: /tmp/masbr
    mongodb_action: backup-database
  roles:
    - ibm.mas_devops.mongodb
```

### Restore Database (CE Operator)
Restore MongoDB databases from a backup to an existing MongoDB instance without recreating the instance resources.

**Use Case**: This action is ideal when you need to restore database data to an already running MongoDB instance, such as recovering from data corruption or restoring specific databases.

**Prerequisites**:
- MongoDB instance must already be installed and running
- MongoDB version must match the backup version
- Backup files must be available in the specified backup directory

```yaml
- hosts: localhost
  any_errors_fatal: true
  vars:
    mongodb_action: restore-database
    mas_instance_id: masinst1
    mongodb_backup_version: 20251212-021316
    mas_backup_dir: /tmp/masbr
    mongodb_namespace: mongoce
    mongodb_instance_name: mas-mongo-ce
  roles:
    - ibm.mas_devops.mongodb
```

**What this does**:
1. Validates that the backup exists at the specified location
2. Verifies the MongoDB instance is running in the specified namespace
3. Checks version compatibility between backup and running instance
4. Restores database data using `mongorestore` command
5. Preserves all existing instance configuration and resources

**Note**: This action does NOT restore instance resources (secrets, certificates, CRs). Use the `restore` action for full instance restoration.

### Full Restore (CE Operator)
Perform a complete restoration of MongoDB instance including all Kubernetes resources and database data from a backup.

**Use Case**: This action is ideal for disaster recovery scenarios where you need to recreate the entire MongoDB instance from scratch, including all configuration, secrets, certificates, and data.

**Prerequisites**:
- Backup files must be available in the specified backup directory
- Backup must include instance resources (secrets, certificates, CRs)
- Target cluster must have cert-manager installed
- Sufficient storage and resources available

```yaml
- hosts: localhost
  any_errors_fatal: true
  vars:
    mongodb_action: restore
    mas_instance_id: masinst1
    mongodb_backup_version: 20251212-021316
    mas_backup_dir: /tmp/masbr
  roles:
    - ibm.mas_devops.mongodb
```

**What this does**:
1. Validates backup files and required variables
2. Restores namespace, secrets, and ConfigMaps
3. Restores CRDs and RBAC resources
4. Restores MongoDB Operator deployment
5. Restores Certificate Manager resources
6. Restores MongoDBCommunity Custom Resource
7. Waits for MongoDB instance to be fully operational
8. Restores database data using `mongorestore`

**Note**: This is a complete restoration that recreates the MongoDB instance from scratch. Use `restore-database` action if you only need to restore data to an existing instance.

### Install from Backup (CE Operator)
Deploy a new MongoDB instance using configuration from a backup and restore data from a backup. This is useful for disaster recovery or migrating MongoDB to a new cluster.

```yaml
- hosts: localhost
  any_errors_fatal: true
  vars:
    mongodb_action: install
    mas_instance_id: masinst1
    mongodb_backup_version: 20251212-021316
    mas_backup_dir: /tmp/masbr
  roles:
    - ibm.mas_devops.mongodb
```


**Purpose**: Specifies which backup version to restore from. This allows point-in-time recovery to a specific backup.

**When to use**:
- Always required when performing restore operations
- Use to restore to a specific point in time
- Verify backup version exists before attempting restore

**Valid values**: Timestamp in format `YYYYMMDDHHMMSS` (e.g., `20240621021316`)

**Impact**: Restores MongoDB to the state captured in the specified backup. All data after this backup will be lost. This is a destructive operation.

**Related variables**:
- `mongodb_action`: Must be set to `restore`

**Note**: **Verify backup version before restoring**. List available backups in storage location first. Restore is destructive and cannot be undone without another backup.


## Role Variables - IBM Cloud
#### ibm_mongo_name
Name for the IBM Cloud Databases for MongoDB instance.

- **Required** when `mongodb_provider=ibm`
- Environment Variable: `IBM_MONGO_NAME`
- Default Value: `mongo-${MAS_INSTANCE_ID}`

**Purpose**: Identifies the MongoDB database instance in IBM Cloud. This name is used for resource identification, billing, and management within IBM Cloud.

**When to use**:
- Always required when using IBM Cloud as the MongoDB provider
- Use default naming convention for consistency across MAS instances
- Customize only if organizational naming standards require it

**Valid values**: Valid IBM Cloud resource name (alphanumeric, hyphens allowed, must start with letter)

**Impact**: This name appears in IBM Cloud console, billing reports, and resource lists. Changing it after creation requires recreating the database instance.

**Related variables**:
- `mas_instance_id`: Default name includes this value
- `mongodb_provider`: Must be set to `ibm`

**Note**: Choose a descriptive name that identifies the MAS instance and environment. The name cannot be changed after creation.

#### ibm_mongo_admin_password
Administrator password for the IBM Cloud MongoDB instance.

- **Optional**
- Environment Variable: `IBM_MONGO_ADMIN_PASSWORD`
- Default Value: Auto-generated 20-character string

**Purpose**: Sets the password for the MongoDB administrator user. If not provided, a secure random password is automatically generated.

**When to use**:
- Set explicitly if you need to know the password in advance
- Leave unset to use auto-generated secure password (recommended)
- Set if integrating with external password management systems

**Valid values**: String meeting IBM Cloud password requirements (minimum length, complexity)

**Impact**: This password is used for administrative access to the MongoDB instance. Auto-generated passwords are stored in Kubernetes secrets.

**Related variables**:
- `ibm_mongo_admin_credentials_secret_name`: Secret where credentials are stored

**Note**: Auto-generated passwords are more secure. If setting manually, ensure password meets security requirements and is stored securely.

#### ibm_mongo_admin_credentials_secret_name
Name of the Kubernetes secret containing MongoDB admin credentials.

- **Optional**
- Environment Variable: `IBM_MONGO_ADMIN_CREDENTIALS_SECRET_NAME`
- Default Value: `<mongo-name>-admin-credentials`

**Purpose**: Specifies the Kubernetes secret name where MongoDB administrator credentials are stored. This secret is created automatically by the role.

**When to use**:
- Customize if organizational standards require specific secret naming
- Use default for standard deployments
- Reference this secret name in other automation

**Valid values**: Valid Kubernetes secret name

**Impact**: The secret contains admin username and password for MongoDB access. Other roles and applications reference this secret for database connectivity.

**Related variables**:
- `ibm_mongo_name`: Default secret name includes this value
- `ibm_mongo_admin_password`: Password stored in this secret

#### ibm_mongo_service_credentials_secret_name
Name of the Kubernetes secret containing MongoDB service credentials.

- **Optional**
- Environment Variable: `IBM_MONGO_SERVICE_CREDENTIALS_SECRET_NAME`
- Default Value: `<mongo-name>-service-credentials`

**Purpose**: Specifies the Kubernetes secret name where MongoDB service-level credentials are stored. These credentials are used by MAS applications to connect to MongoDB.

**When to use**:
- Customize if organizational standards require specific secret naming
- Use default for standard deployments
- Reference this secret name when configuring MAS applications

**Valid values**: Valid Kubernetes secret name

**Impact**: The secret contains connection strings and credentials for application-level MongoDB access. MAS applications use this secret to connect to the database.

**Related variables**:
- `ibm_mongo_name`: Default secret name includes this value

#### ibm_mongo_resourcegroup
IBM Cloud resource group for MongoDB instance placement.

- **Required** when `mongodb_provider=ibm`
- Environment Variable: `IBM_MONGO_RESOURCEGROUP`
- Default Value: `Default`

**Purpose**: Specifies which IBM Cloud resource group will contain the MongoDB instance. Resource groups organize IBM Cloud resources for access control and billing.

**When to use**:
- Always required when using IBM Cloud provider
- Use `Default` for simple deployments
- Specify custom resource group for organizational resource management
- Align with IBM Cloud IAM and billing structure

**Valid values**: Name of an existing IBM Cloud resource group in your account

**Impact**: Determines access control, billing allocation, and resource organization. Users need appropriate IAM permissions for the specified resource group.

**Related variables**:
- `ibmcloud_apikey`: API key must have access to the specified resource group

**Note**: Ensure the resource group exists and your API key has permissions to create resources in it.

#### ibm_mongo_region
IBM Cloud region where MongoDB instance will be deployed.

- **Required** when `mongodb_provider=ibm`
- Environment Variable: `IBM_MONGO_REGION`
- Default Value: `us-east`

**Purpose**: Specifies the geographic region for MongoDB deployment. Region selection affects latency, data residency, and availability.

**When to use**:
- Always required when using IBM Cloud provider
- Choose region closest to your OpenShift cluster for lowest latency
- Consider data residency requirements for compliance
- Use default (`us-east`) if no specific requirements

**Valid values**: Valid IBM Cloud region (e.g., `us-east`, `us-south`, `eu-gb`, `eu-de`, `jp-tok`, `au-syd`)

**Impact**: Affects network latency between OpenShift and MongoDB, data residency compliance, and regional pricing. Cannot be changed after creation.

**Related variables**:
- `ibmcloud_apikey`: API key must have access to the specified region

**Note**: Choose region carefully as it cannot be changed. Consider deploying MongoDB in the same region as your OpenShift cluster for best performance.

#### ibmcloud_apikey
IBM Cloud API key for authentication and resource management.

- **Required** when `mongodb_provider=ibm`
- Environment Variable: `IBMCLOUD_APIKEY`
- Default Value: None

**Purpose**: Provides authentication credentials for creating and managing IBM Cloud resources. The API key must have sufficient permissions to create and manage Databases for MongoDB instances.

**When to use**:
- Always required when using IBM Cloud provider
- Must have permissions for the target resource group and region
- Should be stored securely (e.g., in Ansible Vault or external secret management)

**Valid values**: Valid IBM Cloud API key string

**Impact**: This key is used to authenticate all IBM Cloud API calls. Insufficient permissions will cause deployment failures.

**Related variables**:
- `ibm_mongo_resourcegroup`: API key must have access to this resource group
- `ibm_mongo_region`: API key must have access to this region

**Note**: **Never commit API keys to source control**. Use secure secret management. Ensure the API key has appropriate IAM permissions for Databases for MongoDB service.

#### ibm_mongo_plan
IBM Cloud service plan for MongoDB instance.

- **Optional**
- Environment Variable: `IBM_MONGO_PLAN`
- Default Value: `standard`

**Purpose**: Specifies the IBM Cloud service plan tier for MongoDB. Different plans offer different performance, availability, and pricing characteristics.

**When to use**:
- Use `standard` (default) for most production deployments
- Consider `enterprise` plan for critical workloads requiring higher SLA
- Review IBM Cloud pricing and plan features before selecting

**Valid values**: `standard`, `enterprise` (check IBM Cloud documentation for current plan options)

**Impact**: Affects pricing, performance characteristics, SLA, and available features. Plan cannot be changed after creation without recreating the instance.

**Related variables**:
- `ibm_mongo_memory`, `ibm_mongo_disk`, `ibm_mongo_cpu`: Resource allocations vary by plan

**Note**: Review IBM Cloud Databases for MongoDB plan documentation for current offerings and pricing.

#### ibm_mongo_service
IBM Cloud service type identifier for MongoDB.

- **Required** (Read-only constant)
- Environment Variable: None (internal constant)
- Default Value: `databases-for-mongodb`

**Purpose**: Identifies the IBM Cloud service type. This is a fixed value used internally by the role.

**When to use**: This is set automatically by the role and should not be modified.

**Valid values**: `databases-for-mongodb`

**Impact**: Used in IBM Cloud API calls to specify the service type.

**Note**: This is a constant value and does not need to be set by users.

#### ibm_mongo_service_endpoints
Network endpoint type for MongoDB connectivity.

- **Optional**
- Environment Variable: `IBM_MONGO_SERVICE_ENDPOINTS`
- Default Value: `public`

**Purpose**: Determines whether MongoDB is accessible via public internet or private network only. Private endpoints provide better security and performance for cluster-to-database communication.

**When to use**:
- Use `public` for simple deployments or when OpenShift cluster lacks private network connectivity
- Use `private` for production deployments with private network connectivity (recommended)
- Private endpoints require IBM Cloud private network configuration

**Valid values**: `public`, `private`

**Impact**:
- `public`: MongoDB accessible over internet (requires firewall rules)
- `private`: MongoDB accessible only via IBM Cloud private network (more secure, lower latency)

**Related variables**: Network configuration must support the chosen endpoint type

**Note**: Private endpoints are recommended for production. Ensure your OpenShift cluster can reach IBM Cloud private network if using `private`.

#### ibm_mongo_version
MongoDB version to deploy in IBM Cloud.

- **Optional**
- Environment Variable: `IBM_MONGO_VERSION`
- Default Value: `4.2`

**Purpose**: Specifies which MongoDB version to deploy. Version selection affects available features, performance, and compatibility.

**When to use**:
- Use default (`4.2`) for compatibility with older MAS versions
- Specify newer version (e.g., `5.0`, `6.0`) for new deployments
- Check MAS compatibility matrix before selecting version

**Valid values**: MongoDB versions supported by IBM Cloud Databases (e.g., `4.2`, `4.4`, `5.0`, `6.0`)

**Impact**: Affects available MongoDB features, performance characteristics, and MAS compatibility. Version cannot be easily downgraded.

**Related variables**:
- Check MAS compatibility requirements before selecting version

**Note**: Verify version compatibility with your MAS version. Newer MongoDB versions may require MAS updates.

#### ibm_mongo_memory
Memory allocation per MongoDB member in MB.

- **Optional**
- Environment Variable: `IBM_MONGO_MEMORY`
- Default Value: `3840` (3.75 GB)

**Purpose**: Specifies memory allocation for each MongoDB replica set member. Memory affects caching performance and query execution.

**When to use**:
- Use default (3840 MB) for development or small deployments
- Increase for production workloads (8192 MB or higher recommended)
- Increase for large datasets to improve cache hit rates

**Valid values**: Integer in MB, minimum varies by plan (typically 1024 MB minimum)

**Impact**: Higher memory improves performance through better caching but increases costs. Total cost = memory × number of members.

**Related variables**:
- `ibm_mongo_plan`: Available memory ranges vary by plan
- `ibm_mongo_disk`: Balance memory and disk allocation

**Note**: IBM Cloud charges based on allocated memory. Production deployments typically need 8GB+ per member.

#### ibm_mongo_disk
Disk storage allocation per MongoDB member in MB.

- **Optional**
- Environment Variable: `IBM_MONGO_DISK`
- Default Value: `30720` (30 GB)

**Purpose**: Specifies disk storage for each MongoDB replica set member. Storage holds databases, indexes, and operational logs.

**When to use**:
- Use default (30 GB) for development or small datasets
- Increase for production workloads based on data volume
- Plan for data growth and backup storage needs

**Valid values**: Integer in MB, minimum varies by plan (typically 5120 MB minimum)

**Impact**: Affects storage capacity and costs. Disk can be expanded but not shrunk. Total storage = disk × number of members.

**Related variables**:
- `ibm_mongo_plan`: Available disk ranges vary by plan
- `ibm_mongo_memory`: Balance memory and disk allocation

**Note**: Plan for data growth. Disk can be expanded online but cannot be reduced. Monitor storage usage to avoid running out of space.

#### ibm_mongo_cpu
Dedicated CPU cores per MongoDB member.

- **Optional**
- Environment Variable: `IBM_MONGO_CPU`
- Default Value: `0` (shared CPU)

**Purpose**: Specifies dedicated CPU cores for each MongoDB member. Dedicated CPUs provide consistent performance but increase costs.

**When to use**:
- Use `0` (default) for shared CPU, suitable for development and light workloads
- Set to `3` or higher for production workloads requiring consistent performance
- Dedicated CPUs recommended for production environments

**Valid values**: `0` (shared), or integer ≥ 3 for dedicated CPUs

**Impact**:
- `0`: Shared CPU, lower cost, variable performance
- `≥3`: Dedicated CPUs, higher cost, consistent performance

**Related variables**:
- `ibm_mongo_plan`: CPU options vary by plan
- `ibm_mongo_memory`: Balance CPU and memory allocation

**Note**: Dedicated CPUs significantly increase costs but provide predictable performance. Production workloads typically need dedicated CPUs.

#### ibm_mongo_backup_id
IBM Cloud backup CRN (Cloud Resource Name) for restore operations.

- **Required** when `is_restore=true`
- Environment Variable: `IBM_MONGO_BACKUP_ID`
- Default Value: None

**Purpose**: Specifies the IBM Cloud backup resource to restore from. The CRN uniquely identifies a specific backup in IBM Cloud.

**When to use**:
- Required only when restoring from an IBM Cloud backup
- Obtain CRN from IBM Cloud console or CLI
- Leave unset for new deployments

**Valid values**: Valid IBM Cloud CRN for a MongoDB backup (format: `crn:v1:...`)

**Impact**: Restores MongoDB to the state captured in the specified backup. All current data will be replaced.

**Related variables**:
- `is_restore`: Must be set to `true`
- `restored_mongodb_service_name`: Name for the restored service

**Note**: **Verify backup CRN before restoring**. Restore is destructive and replaces all current data. Test restore procedures in non-production first.

#### is_restore
Flag to enable restore from IBM Cloud backup.

- **Optional**
- Environment Variable: `IS_RESTORE`
- Default Value: `false`

**Purpose**: Controls whether to create a new MongoDB instance or restore from an existing backup. Acts as a safety flag to prevent accidental restores.

**When to use**:
- Set to `true` only when intentionally restoring from backup
- Leave as `false` (default) for new deployments
- Must be explicitly set to perform restore

**Valid values**: `true`, `false`

**Impact**: When `true`, creates MongoDB instance from backup instead of fresh deployment. Requires `ibm_mongo_backup_id` and `restored_mongodb_service_name`.

**Related variables**:
- `ibm_mongo_backup_id`: Required when `true`
- `restored_mongodb_service_name`: Required when `true`

**Note**: **Always verify backup details before setting to `true`**. Restore operations cannot be undone without another backup.

#### restored_mongodb_service_name
Name for the MongoDB service when restoring from backup.

- **Required** when `is_restore=true`
- Environment Variable: `RESTORED_MONGODB_SERVICE_NAME`
- Default Value: None

**Purpose**: Specifies the name for the new MongoDB service created from backup. This allows restoring to a different service name than the original.

**When to use**:
- Required only when `is_restore=true`
- Can be same as or different from original service name
- Use different name to restore alongside existing instance for testing

**Valid values**: Valid IBM Cloud resource name

**Impact**: The restored MongoDB instance will have this name in IBM Cloud. Choose carefully as it affects resource identification and billing.

**Related variables**:
- `is_restore`: Must be set to `true`
- `ibm_mongo_backup_id`: Backup to restore from
- `ibm_mongo_name`: Original service name (can be different)

**Note**: Using a different name allows side-by-side comparison of restored and current instances before switching over.


## Role Variables - AWS DocumentDB

#### aws_access_key_id
AWS account access key ID for authentication.

- **Required** when `mongodb_provider=aws`
- Environment Variable: `AWS_ACCESS_KEY_ID`
- Default Value: None

**Purpose**: Provides AWS authentication credentials for creating and managing DocumentDB resources. The access key must have sufficient IAM permissions for DocumentDB, VPC, and related services.

**When to use**:
- Always required when using AWS DocumentDB provider
- Must have IAM permissions for DocumentDB, EC2 (VPC/subnets/security groups)
- Should be stored securely (e.g., in Ansible Vault or external secret management)

**Valid values**: Valid AWS access key ID string

**Impact**: This key is used to authenticate all AWS API calls. Insufficient permissions will cause deployment failures.

**Related variables**:
- `aws_secret_access_key`: Must be provided together
- `aws_region`: Access key must have permissions in the target region

**Note**: **Never commit AWS credentials to source control**. Use secure secret management. Ensure the IAM user/role has appropriate permissions for DocumentDB and VPC operations.

#### aws_secret_access_key
AWS account secret access key for authentication.

- **Required** when `mongodb_provider=aws`
- Environment Variable: `AWS_SECRET_ACCESS_KEY`
- Default Value: None

**Purpose**: Provides the secret component of AWS authentication credentials. Works together with `aws_access_key_id` to authenticate AWS API requests.

**When to use**:
- Always required when using AWS DocumentDB provider
- Must correspond to the provided `aws_access_key_id`
- Should be stored securely

**Valid values**: Valid AWS secret access key string

**Impact**: Used with access key ID to authenticate AWS API calls. Invalid or mismatched credentials will cause authentication failures.

**Related variables**:
- `aws_access_key_id`: Must be provided together

**Note**: **Store securely and never commit to source control**. Rotate credentials regularly following AWS security best practices.

#### aws_region
AWS region where DocumentDB cluster will be deployed.

- **Required** when `mongodb_provider=aws`
- Environment Variable: `AWS_REGION`
- Default Value: `us-east-2`

**Purpose**: Specifies the geographic AWS region for DocumentDB deployment. Region selection affects latency, data residency, availability zones, and pricing.

**When to use**:
- Always required when using AWS DocumentDB provider
- Choose region closest to your OpenShift cluster for lowest latency
- Consider data residency requirements for compliance
- Use default (`us-east-2`) if no specific requirements

**Valid values**: Valid AWS region code (e.g., `us-east-1`, `us-east-2`, `us-west-2`, `eu-west-1`, `ap-southeast-1`)

**Impact**: Affects network latency, data residency compliance, available availability zones, and regional pricing. Cannot be changed after creation.

**Related variables**:
- `vpc_id`: VPC must exist in the specified region
- `aws_access_key_id`: Credentials must have permissions in this region

**Note**: Choose region carefully as it cannot be changed. Deploy DocumentDB in the same region as your OpenShift cluster for best performance.

#### vpc_id
AWS VPC ID where DocumentDB resources will be created.

- **Required** when `mongodb_provider=aws`
- Environment Variable: `VPC_ID`
- Default Value: None

**Purpose**: Specifies the AWS Virtual Private Cloud where DocumentDB cluster, subnets, and security groups will be created. The VPC provides network isolation and connectivity.

**When to use**:
- Always required when using AWS DocumentDB provider
- Use the same VPC as your OpenShift cluster for direct connectivity
- VPC must exist in the specified `aws_region`

**Valid values**: Valid AWS VPC ID (format: `vpc-xxxxxxxxxxxxxxxxx`)

**Impact**: Determines network connectivity and security boundaries. DocumentDB will only be accessible from resources within this VPC or connected networks.

**Related variables**:
- `aws_region`: VPC must exist in this region
- `docdb_cidr_az1`, `docdb_cidr_az2`, `docdb_cidr_az3`: Subnets created within this VPC
- `docdb_ingress_cidr`, `docdb_egress_cidr`: Should match VPC CIDR ranges

**Note**: Ensure the VPC has sufficient available IP addresses and appropriate routing for DocumentDB connectivity.

#### docdb_cluster_name
Name for the AWS DocumentDB cluster.

- **Required** when `mongodb_provider=aws`
- Environment Variable: `DOCDB_CLUSTER_NAME`
- Default Value: None

**Purpose**: Identifies the DocumentDB cluster in AWS. This name is used for resource identification, tagging, and as a prefix for related resources.

**When to use**:
- Always required when using AWS DocumentDB provider
- Choose a descriptive name that identifies the MAS instance and environment
- Name is used as prefix for subnet groups and security groups

**Valid values**: Valid AWS DocumentDB cluster identifier (lowercase, alphanumeric, hyphens, must start with letter)

**Impact**: This name appears in AWS console, CloudWatch metrics, and billing. Related resources (subnet group, security group) are named based on this value.

**Related variables**:
- `docdb_subnet_group_name`: Defaults to `docdb-{cluster_name}`
- `docdb_security_group_name`: Defaults to `docdb-{cluster_name}`
- `docdb_admin_credentials_secret_name`: Defaults to `{cluster_name}-admin-credentials`

**Note**: Choose a meaningful name as it cannot be easily changed. The name must be unique within your AWS account and region.

#### docdb_subnet_group_name
Name for the DocumentDB subnet group.

- **Optional**
- Environment Variable: `DOCDB_SUBNET_GROUP_NAME`
- Default Value: `docdb-{{ docdb_cluster_name }}`

**Purpose**: Specifies the name for the DocumentDB subnet group that defines which subnets the cluster can use. The role creates this subnet group automatically.

**When to use**:
- Use default naming for standard deployments
- Customize only if organizational naming standards require it

**Valid values**: Valid AWS subnet group name

**Impact**: The subnet group associates the DocumentDB cluster with specific subnets across availability zones.

**Related variables**:
- `docdb_cluster_name`: Default name includes this value
- `docdb_cidr_az1`, `docdb_cidr_az2`, `docdb_cidr_az3`: Subnets included in this group

**Note**: This is automatically created by the role. Default naming is recommended for consistency.

#### docdb_security_group_name
Name for the DocumentDB security group.

- **Optional**
- Environment Variable: `DOCDB_SECURITY_GROUP_NAME`
- Default Value: `docdb-{{ docdb_cluster_name }}`

**Purpose**: Specifies the name for the security group that controls network access to the DocumentDB cluster. The role creates this security group automatically.

**When to use**:
- Use default naming for standard deployments
- Customize only if organizational naming standards require it

**Valid values**: Valid AWS security group name

**Impact**: The security group defines firewall rules for DocumentDB access based on `docdb_ingress_cidr` and `docdb_egress_cidr`.

**Related variables**:
- `docdb_cluster_name`: Default name includes this value
- `docdb_ingress_cidr`: Allowed source CIDR for inbound traffic
- `docdb_egress_cidr`: Allowed destination CIDR for outbound traffic

**Note**: This is automatically created by the role. Default naming is recommended for consistency.

#### docdb_admin_credentials_secret_name
Name of the Kubernetes secret containing DocumentDB admin credentials.

- **Optional**
- Environment Variable: `DOCDB_ADMIN_CREDENTIALS_SECRET_NAME`
- Default Value: `{{ docdb_cluster_name }}-admin-credentials`

**Purpose**: Specifies the Kubernetes secret name where DocumentDB administrator credentials are stored. This secret is created automatically by the role.

**When to use**:
- Use default naming for standard deployments
- Customize only if organizational naming standards require it

**Valid values**: Valid Kubernetes secret name

**Impact**: The secret contains admin username and password for DocumentDB access. MAS and other applications reference this secret for database connectivity.

**Related variables**:
- `docdb_cluster_name`: Default name includes this value
- `docdb_master_username`: Username stored in this secret

**Note**: This secret is created in the MAS core namespace. Default naming is recommended for consistency.

#### docdb_engine_version
DocumentDB engine version to deploy.

- **Optional**
- Environment Variable: `DOCDB_ENGINE_VERSION`
- Default Value: `5.0.0`

**Purpose**: Specifies the DocumentDB engine version. MAS requires DocumentDB 5.0.0 for MongoDB compatibility.

**When to use**:
- Use default (`5.0.0`) for MAS deployments (required)
- Do not change unless specifically required by MAS version

**Valid values**: `5.0.0` (only version supported by MAS)

**Impact**: Determines MongoDB compatibility and available features. MAS is only certified with DocumentDB 5.0.0.

**Related variables**: None

**Note**: **MAS only supports DocumentDB 5.0.0**. Do not change this value unless MAS documentation explicitly supports other versions.

#### docdb_master_username
Master username for DocumentDB cluster administration.

- **Optional**
- Environment Variable: `DOCDB_MASTER_USERNAME`
- Default Value: `docdbadmin`

**Purpose**: Specifies the master administrator username for the DocumentDB cluster. This user has full administrative privileges.

**When to use**:
- Use default (`docdbadmin`) for standard deployments
- Customize if organizational security policies require specific usernames

**Valid values**: Valid DocumentDB username (alphanumeric, must start with letter, 1-63 characters)

**Impact**: This username is used for administrative access and is stored in the Kubernetes secret specified by `docdb_admin_credentials_secret_name`.

**Related variables**:
- `docdb_admin_credentials_secret_name`: Secret where credentials are stored

**Note**: Choose carefully as the master username cannot be changed after cluster creation.

#### docdb_instance_class
AWS instance class for DocumentDB instances.

- **Optional**
- Environment Variable: `DOCDB_INSTANCE_CLASS`
- Default Value: `db.t3.medium`

**Purpose**: Specifies the compute and memory capacity for each DocumentDB instance. Instance class affects performance, availability, and cost.

**When to use**:
- Use `db.t3.medium` (default) for development or small deployments
- Use `db.r5.large` or larger for production workloads
- Consider `db.r6g` instances for better price/performance (ARM-based)

**Valid values**: Valid DocumentDB instance class (e.g., `db.t3.medium`, `db.r5.large`, `db.r5.xlarge`, `db.r6g.large`)

**Impact**: Affects CPU, memory, network performance, and cost. Larger instances provide better performance but cost more.

**Related variables**:
- `docdb_instance_number`: Total cost = instance class cost × number of instances

**Note**: Production deployments typically need `db.r5.large` or larger. Review AWS DocumentDB pricing and instance specifications.

#### docdb_instance_number
Number of DocumentDB instances in the cluster.

- **Optional**
- Environment Variable: `DOCDB_INSTANCE_NUMBER`
- Default Value: `3`

**Purpose**: Determines the number of instances in the DocumentDB cluster. More instances provide higher availability and read scalability.

**When to use**:
- Use default (`3`) for production deployments with high availability
- Use `1` only for development or testing (no high availability)
- Use `5` or more for critical workloads requiring higher availability

**Valid values**: Integer from 1 to 16

**Impact**:
- More instances = higher availability and read capacity but higher cost
- Instances are distributed across availability zones for fault tolerance
- Total cost = instance class cost × number of instances

**Related variables**:
- `docdb_instance_class`: Determines per-instance cost and performance
- `docdb_cidr_az1`, `docdb_cidr_az2`, `docdb_cidr_az3`: Instances distributed across these AZs

**Note**: Production deployments should use 3 or more instances for high availability. Single instance has no failover capability.

#### docdb_instance_identifier_prefix
Prefix for DocumentDB instance identifiers.

- **Required** when `mongodb_provider=aws`
- Environment Variable: `DOCDB_INSTANCE_IDENTIFIER_PREFIX`
- Default Value: None

**Purpose**: Specifies the prefix used to name individual DocumentDB instances. Instance names are formed as `{prefix}-{number}`.

**When to use**:
- Always required when using AWS DocumentDB provider
- Use a descriptive prefix that identifies the cluster and environment
- Typically matches or relates to `docdb_cluster_name`

**Valid values**: Valid AWS instance identifier prefix (lowercase, alphanumeric, hyphens)

**Impact**: Instance names appear in AWS console and CloudWatch metrics. Choose a meaningful prefix for easy identification.

**Related variables**:
- `docdb_cluster_name`: Typically related to cluster name

**Note**: Instance identifiers are formed as `{prefix}-1`, `{prefix}-2`, etc. Choose a clear, descriptive prefix.

#### docdb_ingress_cidr
CIDR block allowed to connect to DocumentDB cluster.

- **Required** when `mongodb_provider=aws`
- Environment Variable: `DOCDB_INGRESS_CIDR`
- Default Value: None

**Purpose**: Specifies the IPv4 CIDR range from which incoming connections to DocumentDB are allowed. This is used in security group ingress rules.

**When to use**:
- Always required when using AWS DocumentDB provider
- Typically set to the CIDR of your OpenShift cluster's VPC
- Can be set to specific subnet CIDRs for tighter security

**Valid values**: Valid IPv4 CIDR notation (e.g., `10.0.0.0/16`, `172.31.0.0/16`)

**Impact**: Only traffic from this CIDR range can connect to DocumentDB. Too restrictive blocks legitimate traffic; too permissive reduces security.

**Related variables**:
- `vpc_id`: Should match VPC CIDR or subnet CIDRs within the VPC
- `docdb_egress_cidr`: Typically set to same value

**Note**: Set to your OpenShift cluster's VPC CIDR for proper connectivity. Verify CIDR ranges before deployment.

#### docdb_egress_cidr
CIDR block for outbound connections from DocumentDB cluster.

- **Required** when `mongodb_provider=aws`
- Environment Variable: `DOCDB_EGRESS_CIDR`
- Default Value: None

**Purpose**: Specifies the IPv4 CIDR range to which DocumentDB can send outbound connections. This is used in security group egress rules.

**When to use**:
- Always required when using AWS DocumentDB provider
- Typically set to the same value as `docdb_ingress_cidr`
- Set to VPC CIDR for standard deployments

**Valid values**: Valid IPv4 CIDR notation (e.g., `10.0.0.0/16`, `172.31.0.0/16`)

**Impact**: DocumentDB can only send traffic to this CIDR range. Affects ability to respond to client connections.

**Related variables**:
- `docdb_ingress_cidr`: Typically set to same value
- `vpc_id`: Should match VPC CIDR

**Note**: Usually set to the same value as `docdb_ingress_cidr`. Verify CIDR ranges match your network configuration.

#### docdb_cidr_az1
CIDR block for DocumentDB subnet in availability zone 1.

- **Required** when `mongodb_provider=aws`
- Environment Variable: `DOCDB_CIDR_AZ1`
- Default Value: None

**Purpose**: Specifies the IPv4 CIDR for the subnet in the first availability zone. If the subnet exists with tag `Name: {{ docdb_cluster_name }}`, it's used; otherwise, a new subnet is created.

**When to use**:
- Always required when using AWS DocumentDB provider
- Must be within the VPC CIDR range
- Must not overlap with other subnets in the VPC

**Valid values**: Valid IPv4 CIDR notation within VPC range (e.g., `10.0.1.0/24`)

**Impact**: Defines the IP address range for DocumentDB instances in AZ1. Subnet size affects number of available IP addresses.

**Related variables**:
- `vpc_id`: CIDR must be within this VPC's range
- `docdb_cidr_az2`, `docdb_cidr_az3`: Must not overlap with these subnets

**Note**: Plan subnet sizes carefully. Each DocumentDB instance needs an IP address. Use /24 or larger subnets for flexibility.

#### docdb_cidr_az2
CIDR block for DocumentDB subnet in availability zone 2.

- **Required** when `mongodb_provider=aws`
- Environment Variable: `DOCDB_CIDR_AZ2`
- Default Value: None

**Purpose**: Specifies the IPv4 CIDR for the subnet in the second availability zone. If the subnet exists with tag `Name: {{ docdb_cluster_name }}`, it's used; otherwise, a new subnet is created.

**When to use**:
- Always required when using AWS DocumentDB provider
- Must be within the VPC CIDR range
- Must not overlap with other subnets in the VPC

**Valid values**: Valid IPv4 CIDR notation within VPC range (e.g., `10.0.2.0/24`)

**Impact**: Defines the IP address range for DocumentDB instances in AZ2. Required for multi-AZ high availability.

**Related variables**:
- `vpc_id`: CIDR must be within this VPC's range
- `docdb_cidr_az1`, `docdb_cidr_az3`: Must not overlap with these subnets

**Note**: Use different availability zones for AZ1, AZ2, and AZ3 to ensure high availability across zones.

#### docdb_cidr_az3
CIDR block for DocumentDB subnet in availability zone 3.

- **Required** when `mongodb_provider=aws`
- Environment Variable: `DOCDB_CIDR_AZ3`
- Default Value: None

**Purpose**: Specifies the IPv4 CIDR for the subnet in the third availability zone. If the subnet exists with tag `Name: {{ docdb_cluster_name }}`, it's used; otherwise, a new subnet is created.

**When to use**:
- Always required when using AWS DocumentDB provider
- Must be within the VPC CIDR range
- Must not overlap with other subnets in the VPC

**Valid values**: Valid IPv4 CIDR notation within VPC range (e.g., `10.0.3.0/24`)

**Impact**: Defines the IP address range for DocumentDB instances in AZ3. Provides third availability zone for maximum fault tolerance.

**Related variables**:
- `vpc_id`: CIDR must be within this VPC's range
- `docdb_cidr_az1`, `docdb_cidr_az2`: Must not overlap with these subnets

**Note**: Three availability zones provide best fault tolerance. Ensure subnets are in different AZs for proper distribution.

### AWS DocumentDB Secret Rotation Variables

The following variables are used for rotating DocumentDB credentials. These are typically used with `mongodb_action=rotate-secret`.

#### docdb_mongo_instance_name
DocumentDB instance name for secret rotation.

- **Required** when rotating secrets
- Environment Variable: `DOCDB_MONGO_INSTANCE_NAME`
- Default Value: None

**Purpose**: Identifies the specific DocumentDB instance for credential rotation operations.

**When to use**:
- Required when performing secret rotation (`mongodb_action=rotate-secret`)
- Must match an existing DocumentDB instance name

**Valid values**: Valid DocumentDB instance identifier

**Impact**: Specifies which DocumentDB instance's credentials will be rotated.

**Related variables**:
- `docdb_cluster_name`: Instance belongs to this cluster
- `docdb_host`: Host address of this instance

**Note**: Verify instance name before rotation to avoid affecting wrong instance.

#### docdb_host
DocumentDB instance host address for connection.

- **Required** when rotating secrets
- Environment Variable: `DOCDB_HOST`
- Default Value: None

**Purpose**: Specifies the host address of a DocumentDB instance for establishing connection during secret rotation.

**When to use**:
- Required when performing secret rotation
- Use any one host address from the DocumentDB cluster
- Obtain from AWS console or DocumentDB cluster endpoint

**Valid values**: Valid DocumentDB instance hostname or endpoint

**Impact**: Used to connect to DocumentDB for credential rotation operations.

**Related variables**:
- `docdb_port`: Port for this host
- `docdb_mongo_instance_name`: Instance identifier

**Note**: Any instance host from the cluster can be used for rotation operations.

#### docdb_port
DocumentDB instance port number.

- **Required** when rotating secrets
- Environment Variable: `DOCDB_PORT`
- Default Value: None (typically `27017`)

**Purpose**: Specifies the port number for connecting to the DocumentDB instance during secret rotation.

**When to use**:
- Required when performing secret rotation
- Typically `27017` (default DocumentDB port)

**Valid values**: Valid port number (typically `27017`)

**Impact**: Used with `docdb_host` to establish connection for credential rotation.

**Related variables**:
- `docdb_host`: Host address for this port

**Note**: DocumentDB uses port 27017 by default unless customized during cluster creation.

#### docdb_instance_username
Username for which password is being rotated.

- **Required** when rotating secrets
- Environment Variable: `DOCDB_INSTANCE_USERNAME`
- Default Value: None

**Purpose**: Specifies the DocumentDB username whose password will be changed during rotation.

**When to use**:
- Required when performing secret rotation
- Typically the application user or admin user
- Must be an existing DocumentDB user

**Valid values**: Valid DocumentDB username

**Impact**: This user's password will be changed. Applications using this username must be updated with the new password.

**Related variables**:
- `docdb_instance_password_old`: Current password for this user
- `docdb_master_username`: Master user for performing rotation

**Note**: Ensure applications can handle password rotation. Consider using connection pooling with reconnection logic.

#### docdb_instance_password_old
Current password for the user being rotated.

- **Required** when rotating secrets
- Environment Variable: `DOCDB_PASSWORD_OLD`
- Default Value: None

**Purpose**: Provides the current password for authentication before rotation. Used to verify current credentials.

**When to use**:
- Required when performing secret rotation
- Must be the current valid password

**Valid values**: Current password string

**Impact**: Used to authenticate before changing password. Incorrect password will cause rotation to fail.

**Related variables**:
- `docdb_instance_username`: User for this password

**Note**: Store securely. After rotation, this password will no longer be valid.

#### docdb_master_password
DocumentDB master user password for administrative operations.

- **Required** when rotating secrets
- Environment Variable: `DOCDB_MASTER_PASSWORD`
- Default Value: None

**Purpose**: Provides master user credentials for performing password rotation operations. Master user has privileges to change other users' passwords.

**When to use**:
- Required when performing secret rotation
- Must be the current master password

**Valid values**: Valid master password string

**Impact**: Used to authenticate as master user to perform credential rotation.

**Related variables**:
- `docdb_master_username`: Master username for this password

**Note**: **Store master credentials securely**. Never commit to source control.

#### docdb_master_username
DocumentDB master username for administrative operations.

- **Required** when rotating secrets
- Environment Variable: `DOCDB_MASTER_USERNAME`
- Default Value: None

**Purpose**: Specifies the master username for performing password rotation operations. Master user has administrative privileges.

**When to use**:
- Required when performing secret rotation
- Typically `docdbadmin` or the value set during cluster creation

**Valid values**: Valid DocumentDB master username

**Impact**: Used with `docdb_master_password` to authenticate for credential rotation.

**Related variables**:
- `docdb_master_password`: Password for this master user

**Note**: This should match the master username set during DocumentDB cluster creation.

AWS DocumentDB destroy-data action Variables
### mas_instance_id
The specified MAS instance ID

- **Required**
- Environment Variable: `MAS_INSTANCE_ID`
- Default Value: None

### mongo_username
Mongo Username

- Environment Variable: `MONGO_USERNAME`
- Default Value: None

### mongo_password
Mongo password

- Environment Variable: `MONGO_PASSWORD`
- Default Value: None

### config
Mongo Config, please refer to the below example playbook section for details

- **Required**
- Environment Variable: `CONFIG`
- Default Value: None

### certificates
Mongo Certificates, please refer to the below example playbook section for details

- **Required**
- Environment Variable: `CERTIFICATES`
- Default Value: None


## Role Variables - MongoDB Atlas

### Overview

The MongoDB Atlas provider automates the complete lifecycle of Atlas cluster provisioning, including:

1. **Project Creation**: Creates or verifies an Atlas project within your organization
2. **Backup Compliance Policy**: Configures automated backup policies with compliance settings
3. **Cluster Provisioning**: Creates a MongoDB cluster with specified configuration
4. **Database Users**: Creates instance-specific database users with scoped permissions
5. **Secret Management**: Stores connection information in AWS Secrets Manager
   - **Cluster-level secret**: `<account_id>/<cluster_name>/mongo` (empty credentials for cluster metadata)
   - **Instance-level secrets**: `<account_id>/<cluster_name>/<instance_id>/mongo` (with user credentials)

### Atlas Project Configuration

#### atlas_org_id
MongoDB Atlas organization ID where the project will be created.

- **Required** when creating a new project (when `atlas_project_id` is not provided)
- Environment Variable: `ATLAS_ORG_ID`
- Default Value: None

**Purpose**: Identifies the Atlas organization that will contain the project. Required for project creation.

**When to use**: Required when `atlas_project_name` is provided but `atlas_project_id` is not.

**Valid values**: 24-character hexadecimal string (e.g., `507f1f77bcf86cd799439011`)

**Impact**: Determines which organization owns the project and its billing.

**How to find**: Atlas Console → Organization Settings → Organization ID

#### atlas_project_name
Name for the Atlas project to create or find.

- **Required** when `atlas_project_id` is not provided
- Environment Variable: `ATLAS_PROJECT_NAME`
- Default Value: None

**Purpose**: Name of the Atlas project. If a project with this name exists in the organization, it will be used; otherwise, a new project will be created.

**When to use**: Use instead of `atlas_project_id` when you want the role to find or create a project by name.

**Valid values**: Alphanumeric string with spaces, hyphens, and underscores allowed

**Impact**: Determines the project name in Atlas console and API operations.

**Related variables**: Requires `atlas_org_id` when creating a new project. Alternative to `atlas_project_id`.

#### atlas_project_id
MongoDB Atlas project ID where the cluster will be created.

- **Required** when `mongodb_provider=atlas`
- Environment Variable: `ATLAS_PROJECT_ID`
- Default Value: None

**Purpose**: Identifies the Atlas project (organization) that will contain the MongoDB cluster. All Atlas resources are organized under projects.

**When to use**: Always required for Atlas deployments (except restore-database). Obtain from Atlas console under Project Settings.

**Valid values**: 24-character hexadecimal string (e.g., `507f1f77bcf86cd799439011`)

**Impact**: Determines billing, access control, and resource organization for the cluster.

#### atlas_account_id
AWS account ID used to construct the AWS Secrets Manager secret name for Atlas API credentials.

- **Required** when `mongodb_provider=atlas`
- Environment Variable: `ATLAS_ACCOUNT_ID`
- Default Value: None

**Purpose**: Used to construct the AWS Secrets Manager secret name in the format `<atlas_account_id>/mongodb-atlas`. This secret must contain the Atlas API credentials.

**When to use**: Always required for Atlas operations. The secret must be created as a prerequisite (see Prerequisites section).

**Valid values**: AWS account ID (12-digit number, e.g., `123456789012`)

**Impact**: Determines which AWS Secrets Manager secret is used to retrieve Atlas API credentials. The role will fail if the secret does not exist or cannot be accessed.

**Related variables**: Used with `aws_region` to locate the secret in AWS Secrets Manager.

**Note**: The secret `<atlas_account_id>/mongodb-atlas` must be created before running this role. See Prerequisites section for secret creation instructions.

#### aws_region
AWS region where the Atlas credentials secret is stored.

- **Optional** when `mongodb_provider=atlas`
- Environment Variable: `ATLAS_AWS_SECRET_REGION`
- Default Value: `us-east-1`

**Purpose**: Specifies which AWS region to query for the Atlas API credentials secret.

**When to use**: Set when using `atlas_aws_secret_name` and secret is not in us-east-1.

**Valid values**: Valid AWS region name (e.g., `us-east-1`, `eu-west-1`)

**Impact**: Determines which AWS region is queried for the secret.

**Related variables**: Only used when `atlas_aws_secret_name` is set.

#### atlas_cluster_name
Name of the MongoDB Atlas cluster to create or manage.

- **Required** when `mongodb_provider=atlas`
- Environment Variable: `ATLAS_CLUSTER_NAME`
- Default Value: None

**Purpose**: Identifies the Atlas cluster within the project. Used for all cluster operations.

**When to use**: Always required for Atlas deployments.

**Valid values**: Alphanumeric string, 1-64 characters, can include hyphens

**Impact**: Cluster name appears in Atlas console and connection strings.

**Note**: Cannot be changed after cluster creation.

#### atlas_cluster_provider
Cloud provider where the Atlas cluster will be deployed.

- **Required** when `mongodb_provider=atlas`
- Environment Variable: `ATLAS_CLUSTER_PROVIDER`
- Default Value: `AWS`

**Purpose**: Specifies which cloud infrastructure provider hosts the Atlas cluster.

**When to use**: Always required for Atlas deployments.

**Valid values**: `AWS`

**Impact**: Determines available regions, instance sizes, and pricing.

**Note**: VPC peering is only supported when using `AWS` as the cloud provider.

**Related variables**: Must be compatible with `atlas_cluster_region`.

#### atlas_cluster_region
Cloud provider region where the Atlas cluster will be deployed.

- **Required** when `mongodb_provider=atlas`
- Environment Variable: `ATLAS_CLUSTER_REGION`
- Default Value: None

**Purpose**: Specifies the geographic region for cluster deployment, affecting latency and data residency.

**When to use**: Always required for Atlas deployments. Choose region closest to your application.

**Valid values**: Atlas region codes (e.g., `US_EAST_1`, `EU_WEST_1`, `AP_SOUTHEAST_1`)

**Impact**: Affects latency, data residency compliance, and availability zones.

**Related variables**: Must be valid for the selected `atlas_cluster_provider`.

**Note**: Use Atlas region format (underscores), not AWS format (hyphens).

#### atlas_cluster_size
Atlas cluster tier/instance size.

- **Required** when `mongodb_provider=atlas`
- Environment Variable: `ATLAS_CLUSTER_SIZE`
- Default Value: None

**Purpose**: Determines cluster compute and memory resources, affecting performance and cost.

**When to use**: Always required for Atlas deployments. Choose based on workload requirements.

**Valid values**: `M10`, `M20`, `M30`, `M40`, `M50`, `M60`, `M80`, `M140`, `M200`, `M300`, `M400`, `M700`

**Impact**: Affects cluster performance, storage capacity, and hourly cost. M10 is minimum for production.

**Note**: M0/M2/M5 free/shared tiers not supported. Cannot be decreased, only increased.

#### atlas_mongodb_version
MongoDB version to deploy in Atlas cluster.

- **Optional** when `mongodb_provider=atlas`
- Environment Variable: `ATLAS_MONGODB_VERSION`
- Default Value: `6.0`

**Purpose**: Specifies MongoDB version for the cluster.

**When to use**: Override default when specific version is required.

**Valid values**: `6.0`, `7.0`, `8.0` (check Atlas for currently supported versions)

**Impact**: Determines available MongoDB features and compatibility.

**Note**: Version upgrades are supported but downgrades are not.

#### atlas_backup_enabled
Enable automated backups for the Atlas cluster.

- **Optional** when `mongodb_provider=atlas`
- Environment Variable: `ATLAS_BACKUP_ENABLED`
- Default Value: `false`

**Purpose**: Controls whether Atlas creates automated backups of the cluster.

**When to use**: Enable for production clusters. Disable only for temporary/test clusters.

**Valid values**: `true`, `false`

**Impact**: When enabled, Atlas creates continuous backups with point-in-time recovery. Affects cluster cost.

**Note**: Highly recommended for production deployments.

**Related variables**: Required to be `true` when `atlas_backup_compliance_enabled` is enabled.
### Atlas Audit Logging Configuration

MongoDB Atlas Auditing captures database operations for compliance and security monitoring. It records authentication events, authorization failures, and database operations, which is required for FedRAMP, HIPAA, and other regulatory compliance.

#### atlas_audit_enabled
Enable audit logging for the Atlas project.

- **Optional** when `mongodb_provider=atlas`
- Environment Variable: `ATLAS_AUDIT_ENABLED`
- Default Value: `false`

**Purpose**: Enables audit logging to capture database operations, authentication events, and authorization failures for compliance and security monitoring.

**When to use**: Enable for production and staging environments requiring regulatory compliance (FedRAMP, HIPAA, SOC 2, PCI-DSS) or security monitoring.

**Valid values**: `true`, `false`

**Impact**: 
- Captures audit events based on the configured filter
- May impact cluster performance depending on filter complexity
- Generates audit logs that can be accessed via Atlas UI or API
- Additional costs may apply based on log volume

**Note**: Audit logging is configured at the project level and applies to all clusters in the project.

**Related variables**: `atlas_audit_filter`, `atlas_audit_authorization_success`

#### atlas_audit_filter
JSON filter for audit events to capture.

- **Optional** when `atlas_audit_enabled=true`
- Environment Variable: `ATLAS_AUDIT_FILTER`
- Default Value: `{}` (captures all events)

**Purpose**: Defines which database operations and events should be captured in audit logs.

**Valid values**: Valid JSON string representing MongoDB audit filter

**Common filter examples**:
- All events (default): `{}`
- Authentication only: `{"atype": "authenticate"}`
- Failed operations: `{"result": {"$ne": 0}}`
- Specific database: `{"param.ns": {"$regex": "^mydb\\."}}`
- Admin database operations: `{"param.db": "admin"}`

**Compliance use cases**:
- **SOC 2**: Track all authentication and authorization events
- **HIPAA**: Monitor access to protected health information
- **PCI-DSS**: Log all access to cardholder data
- **FedRAMP**: Comprehensive audit trail of all database operations

**Impact**: More specific filters reduce log volume and performance impact.

**Note**: Filter syntax follows MongoDB query language. Invalid JSON will cause configuration to fail.

#### atlas_audit_authorization_success
Log successful authorization events.

- **Optional** when `atlas_audit_enabled=true`
- Environment Variable: `ATLAS_AUDIT_AUTHORIZATION_SUCCESS`
- Default Value: `false`

**Purpose**: Controls whether successful authorization events are logged in addition to failures.

**Valid values**: `true`, `false`

**When to use**: 
- Set to `true` for comprehensive audit trails required by strict compliance frameworks
- Set to `false` to reduce log volume by only capturing authorization failures

**Impact**: 
- `true`: Increases log volume significantly as all successful operations are logged

### Atlas Alert Monitoring Configuration

MongoDB Atlas Alert Monitoring provides proactive notifications for cluster health, performance, and security events. Alerts help identify and resolve issues before they impact users.

**Note**: Alerts are configured per cluster using matchers to target the specific cluster name (`atlas_cluster_name`). Each alert configuration includes a matcher that ensures it only applies to the specified cluster.

#### Alert Categories

**Basic Alerts (Always Enabled)**:
When `atlas_enable_alerts=true`, the following alerts are automatically configured:
- CPU usage (warning and critical thresholds)
- Memory usage (warning and critical thresholds)
- Connection count (warning and critical thresholds)

**Optional Alerts (Require Explicit Enablement)**:
- Cluster health alerts (`atlas_enable_cluster_health_alerts`)
- Additional performance alerts - query performance (`atlas_enable_performance_alerts`)

#### atlas_enable_alerts
Enable alert monitoring for the Atlas cluster.

- **Optional** when `mongodb_provider=atlas`
- Environment Variable: `ATLAS_ENABLE_ALERTS`
- Default Value: `false`

**Purpose**: Enables basic alert monitoring (CPU, memory, connections) with email notifications. Additional alert categories can be enabled separately.

**When to use**: Enable for production and staging environments to receive proactive notifications about potential issues.

**Valid values**: `true`, `false`

**Impact**:
- Automatically configures 6 basic alerts (CPU, memory, connections - warning and critical)
- Sends email notifications when thresholds are exceeded
- Helps prevent downtime by alerting before critical issues occur

**Note**: Requires `atlas_alert_notification_emails` to be configured with at least one email address.

**Related variables**: `atlas_alert_notification_emails`, `atlas_enable_cluster_health_alerts`, `atlas_enable_performance_alerts`

#### atlas_alert_notification_emails
List of email addresses to receive alert notifications.

- **Required** when `atlas_enable_alerts=true`
- Environment Variable: `ATLAS_ALERT_NOTIFICATION_EMAILS`
- Default Value: `[]`

**Purpose**: Specifies email addresses that will receive alert notifications via OCM (Operations Center Manager).

**Valid values**: Comma-separated list of valid email addresses or JSON array

**Examples**:
- Comma-separated: `ocm-team@example.com,monitoring@example.com`
- JSON array: `["ocm-team@example.com", "monitoring@example.com"]`

**Impact**: All specified email addresses will receive notifications for all configured alerts.

**Important**: Use OCM (Operations Center Manager) email addresses only. Do not configure generic or personal email addresses. OCM emails are integrated with incident management systems and ensure proper alert routing and escalation.

**Note**: At least one OCM email address is required when alerts are enabled.

#### atlas_enable_cluster_health_alerts
Enable alerts for cluster health issues.

- **Optional** when `atlas_enable_alerts=true`
- Environment Variable: `ATLAS_ENABLE_CLUSTER_HEALTH_ALERTS`
- Default Value: `false`

**Purpose**: Enables alerts for cluster health events including replication lag, primary election, and node failures.

**Valid values**: `true`, `false`

**Alert types configured**:
- Replication oplog window running out (< 1 hour)
- Primary elected (replica set election)
- No primary available
- Cluster mongos missing

**When to use**: Enable for production and staging environments to monitor cluster stability.

#### atlas_enable_performance_alerts
Enable alerts for performance issues.

- **Optional** when `atlas_enable_alerts=true`
- Environment Variable: `ATLAS_ENABLE_PERFORMANCE_ALERTS`
- Default Value: `false`

**Purpose**: Enables alerts for performance metrics including CPU, memory, disk, and connection usage.

**Valid values**: `true`, `false`

**Alert types configured**:
- CPU usage (warning and critical thresholds)
- Memory usage (warning and critical thresholds)
- Disk usage
- Connection count (warning and critical thresholds)
- Query performance (scanned objects per returned)

**When to use**: Enable for production and staging environments to monitor resource utilization.

**Related variables**: `atlas_alert_cpu_thresholds`, `atlas_alert_memory_thresholds`, `atlas_alert_connection_thresholds`

#### atlas_enable_security_alerts
Enable alerts for security events.

- **Optional** when `atlas_enable_alerts=true`
- Environment Variable: `ATLAS_ENABLE_SECURITY_ALERTS`
- Default Value: `false`

**Purpose**: Enables alerts for security-related events including authentication failures and configuration changes.

**Valid values**: `true`, `false`

**Alert types configured**:
- Too many unhealthy connections
- Users without multi-factor authentication

**When to use**: Enable for all environments to monitor security posture.

#### atlas_alert_cpu_thresholds
CPU utilization percentage thresholds for WARNING and CRITICAL alerts.

- **Optional** when `atlas_enable_performance_alerts=true`
- Environment Variable: `ATLAS_ALERT_CPU_THRESHOLDS`
- Default Value: `[70, 80]`

**Purpose**: Defines CPU usage thresholds as an array `[warning, critical]`. Warning alert triggers at first value, critical at second.

**Valid values**: JSON array of two integers between 0-100

**Impact**: Lower values trigger alerts earlier. Critical threshold should be higher than warning for proper escalation.

**Example**:
```bash
export ATLAS_ALERT_CPU_THRESHOLDS='[70, 80]'
```

#### atlas_alert_memory_thresholds
Memory utilization percentage thresholds for WARNING and CRITICAL alerts.

- **Optional** when `atlas_enable_performance_alerts=true`
- Environment Variable: `ATLAS_ALERT_MEMORY_THRESHOLDS`
- Default Value: `[70, 80]`

**Purpose**: Defines memory usage thresholds as an array `[warning, critical]`. Warning alert triggers at first value, critical at second.

**Valid values**: JSON array of two integers between 0-100

**Impact**: Memory exhaustion can cause performance degradation and OOM errors.

**Example**:
```bash
export ATLAS_ALERT_MEMORY_THRESHOLDS='[70, 80]'
```

#### atlas_alert_connection_thresholds
Connection count thresholds as percentage of maximum for WARNING and CRITICAL alerts.

- **Optional** when `atlas_enable_performance_alerts=true`
- Environment Variable: `ATLAS_ALERT_CONNECTION_THRESHOLDS`
- Default Value: `[70, 80]`

**Purpose**: Defines connection usage thresholds as an array `[warning, critical]`. Warning alert triggers at first value, critical at second.

**Valid values**: JSON array of two integers between 0-100

**Impact**: Connection exhaustion can prevent new connections and cause application failures.

**Example**:
```bash
export ATLAS_ALERT_CONNECTION_THRESHOLDS='[70, 80]'
```

#### atlas_alert_interval_min
Interval in minutes for metric threshold alert evaluation.

- **Optional**
- Environment Variable: `ATLAS_ALERT_INTERVAL_MIN`
- Default Value: `5`

**Purpose**: Defines how frequently Atlas evaluates metric thresholds for all performance alerts (CPU, memory, connections, query performance). This applies to all `OUTSIDE_METRIC_THRESHOLD` alert types.

**Valid values**: Positive integer (minutes)

**Impact**:
- Lower values (e.g., 1-5 minutes) provide faster detection but may increase alert noise
- Higher values (e.g., 10-15 minutes) reduce noise but delay detection
- Affects all metric threshold alerts uniformly

**Note**: This is a required parameter for MongoDB Atlas metric threshold alerts. The default of 5 minutes balances responsiveness with stability.

- `false`: Only logs authorization failures, reducing log volume

**Note**: Most compliance frameworks require logging of both successful and failed authorization attempts.


### Atlas Backup Compliance Policy Configuration

The backup compliance policy enforces backup retention and protection rules at the project level. When enabled, it applies to all clusters in the project.

#### atlas_backup_compliance_enabled
Enable backup compliance policy for the Atlas project.

- **Optional** when `mongodb_provider=atlas`
- Environment Variable: `ATLAS_BACKUP_COMPLIANCE_ENABLED`
- Default Value: `false`

**Purpose**: Enables backup compliance policy with configurable retention schedules and protection settings.

**When to use**: Enable for production environments requiring regulatory compliance or strict backup retention policies.

**Valid values**: `true`, `false`

**Impact**: Enforces backup retention policies, prevents unauthorized backup deletion, and enables compliance features.

**Note**: Requires `atlas_backup_enabled: true` on the cluster. Once enabled, compliance policy cannot be disabled without contacting Atlas support.

**Related variables**: Requires multiple `atlas_compliance_*` variables for configuration.

#### atlas_compliance_authorized_email
Email address of the authorized user for compliance policy changes.

- **Required** when `atlas_backup_compliance_enabled=true`
- Environment Variable: `ATLAS_COMPLIANCE_AUTHORIZED_EMAIL`
- Default Value: `admin@example.com`

**Purpose**: Identifies the user authorized to make changes to the backup compliance policy.

**Valid values**: Valid email address

**Impact**: Used for audit trail and authorization of compliance policy changes.

#### atlas_compliance_authorized_first_name
First name of the authorized user for compliance policy changes.

- **Required** when `atlas_backup_compliance_enabled=true`
- Environment Variable: `ATLAS_COMPLIANCE_AUTHORIZED_FIRST_NAME`
- Default Value: `Admin`

**Purpose**: First name of the authorized user for compliance policy.

**Valid values**: String

#### atlas_compliance_authorized_last_name
Last name of the authorized user for compliance policy changes.

- **Required** when `atlas_backup_compliance_enabled=true`
- Environment Variable: `ATLAS_COMPLIANCE_AUTHORIZED_LAST_NAME`
- Default Value: `User`

**Purpose**: Last name of the authorized user for compliance policy.

**Valid values**: String

#### atlas_compliance_copy_protection
Enable copy protection for backups.

- **Optional** when `atlas_backup_compliance_enabled=true`
- Environment Variable: `ATLAS_COMPLIANCE_COPY_PROTECTION`
- Default Value: `false`

**Purpose**: Prevents copying of backup snapshots to other regions or projects.

**Valid values**: `true`, `false`

**Impact**: When enabled, backups cannot be copied outside the configured region.

#### atlas_compliance_encryption_at_rest
Enable encryption at rest for backups.

- **Optional** when `atlas_backup_compliance_enabled=true`
- Environment Variable: `ATLAS_COMPLIANCE_ENCRYPTION_AT_REST`
- Default Value: `false`

**Purpose**: Ensures all backup snapshots are encrypted at rest.

**Valid values**: `true`, `false`

**Impact**: Adds encryption layer to backup storage.

#### atlas_compliance_pit_enabled
Enable point-in-time restore for compliance backups.

- **Optional** when `atlas_backup_compliance_enabled=true`
- Environment Variable: `ATLAS_COMPLIANCE_PIT_ENABLED`
- Default Value: `false`

**Purpose**: Enables continuous backup with point-in-time recovery capability.

**Valid values**: `true`, `false`

**Impact**: Allows restore to any point in time within the retention window. Increases backup storage costs.

#### atlas_compliance_restore_window_days
Number of days for the restore window.

- **Optional** when `atlas_backup_compliance_enabled=true`
- Environment Variable: `ATLAS_COMPLIANCE_RESTORE_WINDOW_DAYS`
- Default Value: `7`

**Purpose**: Defines how many days of continuous backup history are maintained for point-in-time restore.

**Valid values**: Integer (1-365)

**Impact**: Determines the maximum age of data that can be restored.

#### atlas_compliance_hourly_frequency_interval
Frequency interval for hourly backups (in hours).

- **Optional** when `atlas_backup_compliance_enabled=true`
- Environment Variable: `ATLAS_COMPLIANCE_HOURLY_FREQUENCY_INTERVAL`
- Default Value: `6`

**Purpose**: How often hourly snapshots are taken.

**Valid values**: Integer (1, 2, 4, 6, 8, 12)

**Impact**: More frequent backups provide finer recovery granularity but increase storage costs.

#### atlas_compliance_hourly_retention_unit
Retention unit for hourly backups.

- **Optional** when `atlas_backup_compliance_enabled=true`
- Environment Variable: `ATLAS_COMPLIANCE_HOURLY_RETENTION_UNIT`
- Default Value: `days`

**Purpose**: Unit of time for hourly backup retention.

**Valid values**: `days`, `weeks`, `months`

#### atlas_compliance_hourly_retention_value
Retention value for hourly backups.

- **Optional** when `atlas_backup_compliance_enabled=true`
- Environment Variable: `ATLAS_COMPLIANCE_HOURLY_RETENTION_VALUE`
- Default Value: `7`

**Purpose**: How long to retain hourly backups.

**Valid values**: Integer (1-365 for days, 1-52 for weeks, 1-36 for months)

**Impact**: Longer retention increases storage costs.

#### atlas_compliance_daily_frequency_interval
Frequency interval for daily backups (in days).

- **Optional** when `atlas_backup_compliance_enabled=true`
- Environment Variable: `ATLAS_COMPLIANCE_DAILY_FREQUENCY_INTERVAL`
- Default Value: `1`

**Purpose**: How often daily snapshots are taken.

**Valid values**: Integer (1-365)

#### atlas_compliance_daily_retention_unit
Retention unit for daily backups.

- **Optional** when `atlas_backup_compliance_enabled=true`
- Environment Variable: `ATLAS_COMPLIANCE_DAILY_RETENTION_UNIT`
- Default Value: `days`

**Purpose**: Unit of time for daily backup retention.

**Valid values**: `days`, `weeks`, `months`

#### atlas_compliance_daily_retention_value
Retention value for daily backups.

- **Optional** when `atlas_backup_compliance_enabled=true`
- Environment Variable: `ATLAS_COMPLIANCE_DAILY_RETENTION_VALUE`
- Default Value: `7`

**Purpose**: How long to retain daily backups.

**Valid values**: Integer (1-365 for days, 1-52 for weeks, 1-36 for months)

#### atlas_compliance_weekly_frequency_interval
Frequency interval for weekly backups (in weeks).

- **Optional** when `atlas_backup_compliance_enabled=true`
- Environment Variable: `ATLAS_COMPLIANCE_WEEKLY_FREQUENCY_INTERVAL`
- Default Value: `1`

**Purpose**: How often weekly snapshots are taken.

**Valid values**: Integer (1-52)

#### atlas_compliance_weekly_retention_unit
Retention unit for weekly backups.

- **Optional** when `atlas_backup_compliance_enabled=true`
- Environment Variable: `ATLAS_COMPLIANCE_WEEKLY_RETENTION_UNIT`
- Default Value: `weeks`

**Purpose**: Unit of time for weekly backup retention.

**Valid values**: `weeks`, `months`, `years`

#### atlas_compliance_weekly_retention_value
Retention value for weekly backups.

- **Optional** when `atlas_backup_compliance_enabled=true`
- Environment Variable: `ATLAS_COMPLIANCE_WEEKLY_RETENTION_VALUE`
- Default Value: `4`

**Purpose**: How long to retain weekly backups.

**Valid values**: Integer (1-52 for weeks, 1-36 for months, 1-10 for years)

#### atlas_compliance_monthly_frequency_interval
Frequency interval for monthly backups (in months).

- **Optional** when `atlas_backup_compliance_enabled=true`
- Environment Variable: `ATLAS_COMPLIANCE_MONTHLY_FREQUENCY_INTERVAL`
- Default Value: `1`

**Purpose**: How often monthly snapshots are taken.

**Valid values**: Integer (1-12)

#### atlas_compliance_monthly_retention_unit
Retention unit for monthly backups.

- **Optional** when `atlas_backup_compliance_enabled=true`
- Environment Variable: `ATLAS_COMPLIANCE_MONTHLY_RETENTION_UNIT`
- Default Value: `months`

**Purpose**: Unit of time for monthly backup retention.

**Valid values**: `months`, `years`

#### atlas_compliance_monthly_retention_value
Retention value for monthly backups.

- **Optional** when `atlas_backup_compliance_enabled=true`
- Environment Variable: `ATLAS_COMPLIANCE_MONTHLY_RETENTION_VALUE`
- Default Value: `12`

**Purpose**: How long to retain monthly backups.

**Valid values**: Integer (1-36 for months, 1-10 for years)

#### atlas_compliance_yearly_frequency_interval
Frequency interval for yearly backups (in years).

- **Optional** when `atlas_backup_compliance_enabled=true`
- Environment Variable: `ATLAS_COMPLIANCE_YEARLY_FREQUENCY_INTERVAL`
- Default Value: `1`

**Purpose**: How often yearly snapshots are taken.

**Valid values**: Integer (1-10)

#### atlas_compliance_yearly_retention_unit
Retention unit for yearly backups.

- **Optional** when `atlas_backup_compliance_enabled=true`
- Environment Variable: `ATLAS_COMPLIANCE_YEARLY_RETENTION_UNIT`
- Default Value: `years`

**Purpose**: Unit of time for yearly backup retention.

**Valid values**: `years`

#### atlas_compliance_yearly_retention_value
Retention value for yearly backups.

- **Optional** when `atlas_backup_compliance_enabled=true`
- Environment Variable: `ATLAS_COMPLIANCE_YEARLY_RETENTION_VALUE`
- Default Value: `1`

**Purpose**: How long to retain yearly backups.

**Valid values**: Integer (1-10)

**Impact**: Longer retention increases storage costs significantly.

### Atlas Database Users Configuration

#### atlas_mas_instances
List of MAS instance names for creating instance-specific database users.

- **Optional** when `mongodb_provider=atlas`
- Environment Variable: `ATLAS_MAS_INSTANCES`
- Default Value: `[]`

**Purpose**: Defines MAS instances that will use this cluster. Each instance gets a dedicated database user with scoped permissions.

**When to use**: Provide when deploying Atlas cluster for multiple MAS instances.

**Valid values**: List of instance names or comma-separated string (e.g., `["inst1", "inst2"]` or `"inst1,inst2"`)

**Impact**: Creates one database user per instance with username format `<instance_name>-user`.

**Related variables**: Used with `atlas_store_credentials_in_secret` to create instance-level secrets.

#### atlas_database_users
Multi-user database configuration for Atlas cluster.

- **Optional** when `mongodb_provider=atlas` (alternative to `atlas_db_username`/`atlas_db_password`)
- Environment Variable: Not supported (use playbook vars)
- Default Value: None

**Purpose**: Defines multiple database users with different roles and permissions. Recommended approach for production.

**When to use**: Use for production deployments requiring multiple users with different access levels.

**Valid values**: Dictionary of user configurations with username, auth_database_name, and roles

**Impact**: Creates multiple database users with auto-generated passwords stored in Atlas.

**Related variables**: Alternative to legacy `atlas_db_username`/`atlas_db_password`.

**Example**:
```yaml
atlas_database_users:
  user1:
    username: "app_user"
    auth_database_name: "admin"
    roles:
      - database_name: "admin"
        role_name: "readWriteAnyDatabase"
```

#### atlas_db_username
Legacy single database user username.

- **Optional** when `mongodb_provider=atlas` (alternative to `atlas_database_users`)
- Environment Variable: `ATLAS_DB_USERNAME`
- Default Value: None

**Purpose**: Creates a single database user for Atlas cluster. Legacy approach.

**When to use**: Use for simple deployments with single user. Consider `atlas_database_users` for production.

**Valid values**: Valid MongoDB username string

**Impact**: Creates one database user with specified credentials.

**Related variables**: Must be used with `atlas_db_password`. Alternative: use `atlas_database_users`.

#### atlas_db_password
Legacy single database user password.

- **Optional** when `mongodb_provider=atlas` (alternative to `atlas_database_users`)
- Environment Variable: `ATLAS_DB_PASSWORD`
- Default Value: None

**Purpose**: Password for the single database user. Legacy approach.

**When to use**: Use with `atlas_db_username` for simple deployments.

**Valid values**: Strong password string

**Impact**: Sets password for the database user.

**Related variables**: Must be used with `atlas_db_username`. Alternative: use `atlas_database_users`.

**Note**: Store securely. Never commit to version control.

### Atlas Secret Management Configuration

#### atlas_account_id
AWS account ID for secret naming convention.

- **Required** when `atlas_store_credentials_in_secret=true`
- Environment Variable: `ATLAS_ACCOUNT_ID`
- Default Value: None

**Purpose**: Used to construct secret names in the format `<account_id>/<cluster_name>/mongo` and `<account_id>/<cluster_name>/<instance_id>/mongo`.

**When to use**: Required when storing credentials in AWS Secrets Manager.

**Valid values**: 12-digit AWS account ID

**Impact**: Determines the secret naming structure in AWS Secrets Manager.

**Related variables**: Used with `atlas_store_credentials_in_secret`.

#### atlas_store_credentials_in_secret
Store Atlas connection information in AWS Secrets Manager.

- **Optional** when `mongodb_provider=atlas`
- Environment Variable: `ATLAS_STORE_CREDENTIALS_IN_SECRET`
- Default Value: `false`

**Purpose**: Automatically stores Atlas connection details in AWS Secrets Manager after provisioning. Creates two types of secrets:
- **Cluster-level secret**: `<account_id>/<cluster_name>/mongo` - Contains cluster metadata (hosts, port, CA certificates) with empty username/password
- **Instance-level secrets**: `<account_id>/<cluster_name>/<instance_id>/mongo` - Contains instance-specific credentials (username, password) plus cluster metadata

**When to use**: Enable for production deployments to centralize credential management and enable MAS to retrieve connection information.

**Valid values**: `true`, `false`

**Impact**: Creates/updates AWS Secrets Manager secrets with connection information. Requires AWS CLI configured with appropriate IAM permissions.

**Related variables**: Requires `atlas_account_id`, `atlas_cluster_name`, and `atlas_aws_region`. Works with `atlas_mas_instances` to create instance-level secrets.

**Secret Structure**:
```json
{
  "info": "# YAML content with hosts, port, CA certificates",
  "username": "instance-user",
  "password": "generated-password"
}
```

**Note**: The cluster-level secret has empty `username` and `password` fields (or `docdb_username`/`docdb_password` for compatibility), while instance-level secrets contain actual credentials.

### Atlas VPC/PrivateLink Configuration

#### atlas_vpc_id
AWS VPC ID for VPC peering with Atlas.

- **Optional** when `mongodb_provider=atlas` and `atlas_cluster_provider=AWS` and configuring VPC peering
- Environment Variable: `ATLAS_VPC_ID`
- Default Value: None

**Purpose**: AWS VPC ID for establishing VPC peering connection with Atlas cluster.

**When to use**: Required when configuring VPC peering for private connectivity. VPC peering is only supported for AWS deployments.

**Valid values**: Valid AWS VPC ID (e.g., `vpc-0123456789abcdef0`)

**Impact**: Enables private network connectivity between AWS VPC and Atlas cluster.

**Related variables**: Used with `atlas_aws_region`, `atlas_aws_route_table_ids` or `atlas_aws_subnet_ids`.

#### atlas_aws_region
AWS region for VPC peering configuration.

- **Optional** when `mongodb_provider=atlas` and `atlas_cluster_provider=AWS` and configuring VPC peering
- Environment Variable: `ATLAS_AWS_REGION`
- Default Value: None

**Purpose**: AWS region where VPC peering will be configured.

**When to use**: Required when configuring VPC peering. VPC peering is only supported for AWS deployments.

**Valid values**: Atlas region format (e.g., `US_EAST_1`, `EU_WEST_1`)

**Impact**: Must match the region of the AWS VPC.

**Related variables**: Used with `atlas_vpc_id` for VPC peering.

**Note**: Use Atlas region format (underscores), not AWS format (hyphens).

#### atlas_aws_route_table_ids
AWS route table IDs for VPC peering routes.

- **Optional** when `mongodb_provider=atlas` and `atlas_cluster_provider=AWS` and configuring VPC peering
- Environment Variable: `ATLAS_AWS_ROUTE_TABLE_IDS`
- Default Value: None

**Purpose**: List of AWS route table IDs where Atlas CIDR routes will be added.

**When to use**: Provide when manually specifying route tables for VPC peering. VPC peering is only supported for AWS deployments.

**Valid values**: List of route table IDs or comma-separated string

**Impact**: Routes to Atlas CIDR block added to these route tables.

**Related variables**: Alternative to `atlas_aws_subnet_ids` (which auto-discovers route tables).

#### atlas_aws_subnet_ids
AWS subnet IDs for auto-discovering route tables.

- **Optional** when `mongodb_provider=atlas` and `atlas_cluster_provider=AWS` and configuring VPC peering
- Environment Variable: `ATLAS_AWS_SUBNET_IDS`
- Default Value: None

**Purpose**: List of AWS subnet IDs used to automatically discover associated route tables.

**When to use**: Provide when you want automatic route table discovery instead of manual specification. VPC peering is only supported for AWS deployments.

**Valid values**: List of subnet IDs or comma-separated string

**Impact**: Route tables associated with these subnets are automatically discovered and configured.

**Related variables**: Alternative to `atlas_aws_route_table_ids` (manual specification).

### Important Note: Atlas Restore Functionality

**Why Manual Restore Options Are Provided:**

MongoDB Atlas provides a fully managed backup service with automated backups, point-in-time recovery, and easy restore capabilities through the Atlas console and API. **For normal backup and restore operations, you should use the Atlas managed backup service.**

However, this role includes manual restore functionality for **data migration from AWS DocumentDB scenarios only**.

**Recommendation**:
- **For production backup/restore**: Use Atlas managed backup service (enabled by default with `atlas_backup_enabled: true`)
- **For data migration**: Use the manual restore-database options provided here

#### atlas_mongodb_host
MongoDB Atlas cluster hostname for restore connection.

- **Required** when `mongodb_provider=atlas` and `mongodb_action=restore|restore-database`
- Environment Variable: `ATLAS_MONGODB_HOST`
- Default Value: None

**Purpose**: Specifies the Atlas cluster hostname to connect for restore operation.

**When to use**: Required when restoring MongoDB data to Atlas cluster.

**Valid values**: Atlas cluster hostname (e.g., `cluster0.abc123.mongodb.net`)

**Impact**: Used to build MongoDB connection URI for mongorestore command.

**Related variables**: Used with `atlas_mongodb_username` and `atlas_mongodb_password`.

**Note**: Use the SRV hostname format without `mongodb+srv://` prefix.

#### atlas_mongodb_username
MongoDB database username for restore connection.

- **Required** when `mongodb_provider=atlas` and `mongodb_action=restore|restore-database`
- Environment Variable: `ATLAS_MONGODB_USERNAME`
- Default Value: None

**Purpose**: Database username with write permissions for restore operation.

**When to use**: Required when restoring MongoDB data to Atlas cluster.

**Valid values**: Valid MongoDB username with appropriate permissions

**Impact**: Used for authentication during mongorestore operation.

**Related variables**: Used with `atlas_mongodb_host` and `atlas_mongodb_password`.

**Note**: User must have readWriteAnyDatabase or equivalent permissions.

#### atlas_mongodb_password
MongoDB database password for restore connection.

- **Required** when `mongodb_provider=atlas` and `mongodb_action=restore|restore-database`
- Environment Variable: `ATLAS_MONGODB_PASSWORD`
- Default Value: None

**Purpose**: Database password for authentication during restore.

**When to use**: Required when restoring MongoDB data to Atlas cluster.

**Valid values**: Valid password for the specified username

**Impact**: Used for authentication during mongorestore operation.

**Related variables**: Used with `atlas_mongodb_host` and `atlas_mongodb_username`.

**Note**: Store securely. Never commit to version control.

#### atlas_backup_archive_path
Local path to the MongoDB backup archive file (.tar.gz).

- **Required** when `mongodb_provider=atlas` and `mongodb_action=restore|restore-database`
- Environment Variable: `ATLAS_BACKUP_ARCHIVE_PATH`
- Default Value: None

**Purpose**: Specifies the local filesystem path to the backup archive containing MongoDB data dumps.

**When to use**: Required when restoring MongoDB data from local backup files to Atlas cluster (typically for data migration scenarios).

**Valid values**: Valid local filesystem path to a .tar.gz file (e.g., `/path/to/mongodb-backup-20240621.tar.gz`)

**Impact**: The role will extract this archive and restore the data to the Atlas cluster.

**Related variables**: Used with `atlas_index_file_path`, `atlas_mongodb_host`, `atlas_mongodb_username`, and `atlas_mongodb_password`.

**Note**: This is for the `restore-database` action which uses local files, not the `restore` action which downloads from S3.

#### atlas_index_file_path
Local path to the MongoDB index backup JSON file.

- **Required** when `mongodb_provider=atlas` and `mongodb_action=restore|restore-database`
- Environment Variable: `ATLAS_INDEX_FILE_PATH`
- Default Value: None

**Purpose**: Specifies the local filesystem path to the JSON file containing MongoDB index definitions.

**When to use**: Required when restoring MongoDB data from local backup files to Atlas cluster (typically for data migration scenarios).

**Valid values**: Valid local filesystem path to a JSON file (e.g., `/path/to/mongodb-indexes-20240621.json`)

**Impact**: The role will read this file and recreate indexes after data restore.

**Related variables**: Used with `atlas_backup_archive_path` for the restore-database operation.

**Note**: File must be valid JSON containing index definitions for each database and collection. This is for the `restore-database` action which uses local files, not the `restore` action which downloads from S3.




## Example Playbook

### Install (CE Operator)
```yaml
- hosts: localhost
  any_errors_fatal: true
  vars:
    mongodb_storage_class: ibmc-block-gold
    mas_instance_id: masinst1
    mas_config_dir: ~/masconfig
  roles:
    - ibm.mas_devops.mongodb
```

### Install (IBM Cloud)
```yaml
- hosts: localhost
  any_errors_fatal: true
  vars:
    mas_instance_id: masinst1
    mas_config_dir: ~/masconfig
    mongodb_provider: ibm
    ibmcloud_apikey: apikey****
    ibmcloud_resource_group: mas-test
  roles:
    - ibm.mas_devops.mongodb
```

### Install (MongoDB Atlas)
```yaml
- hosts: localhost
  any_errors_fatal: true
  vars:
    mongodb_provider: atlas
    mongodb_action: install
    
    # Project configuration (creates project if it doesn't exist)
    atlas_org_id: "507f1f77bcf86cd799439011"
    atlas_project_name: "MAS Production"
    
    # Cluster configuration
    atlas_cluster_name: "mas-cluster"
    atlas_cluster_provider: "AWS"
    atlas_aws_region: "US_EAST_1"
    atlas_cluster_size: "M10"
    atlas_mongodb_version: "7.0"
    
    # Backup configuration
    atlas_backup_enabled: true
    atlas_backup_compliance_enabled: true
    atlas_compliance_authorized_email: "admin@example.com"
    atlas_compliance_authorized_first_name: "Admin"
    atlas_compliance_authorized_last_name: "User"
    
    # Audit logging configuration
    atlas_audit_enabled: true
    atlas_audit_filter: '{"atype": "authenticate"}'
    atlas_audit_authorization_success: false
    
    # Alert monitoring configuration
    # Basic alerts (CPU, memory, connections) are automatically enabled
    atlas_enable_alerts: true
    atlas_alert_notification_emails: "ocm-team@example.com,monitoring@example.com"
    
    # Optional: Enable additional alert categories
    atlas_enable_cluster_health_alerts: true
    atlas_enable_performance_alerts: true  # Disk and query performance
    
    # MAS instances (creates dedicated users for each)
    atlas_mas_instances: "inst1,inst2,inst3"
    
    # PrivateLink configuration
    atlas_privatelink_enabled: true
    atlas_vpc_id: "vpc-0123456789abcdef0"
    atlas_subnet_ids: "subnet-111,subnet-222,subnet-333"
    atlas_rosa_cidr_ranges: "10.0.0.0/16"
    
    # Secret management
    atlas_store_credentials_in_secret: true
    atlas_account_id: "123456789012"
    
  roles:
    - ibm.mas_devops.mongodb
```

### Install (MongoDB Atlas - Minimal Configuration)
```yaml
- hosts: localhost
  any_errors_fatal: true
  vars:
    mongodb_provider: atlas
    
    # AWS account ID (used to retrieve credentials from AWS Secrets Manager)
    # Secret name will be: <atlas_account_id>/mongodb-atlas
    atlas_account_id: "123456789012"
    aws_region: "us-east-1"
    
    # Use existing project
    atlas_project_id: "507f1f77bcf86cd799439011"
    
    # Cluster configuration
    atlas_cluster_name: "mas-dev-cluster"
    atlas_aws_region: "US_EAST_1"
    atlas_cluster_size: "M10"
    
  roles:
    - ibm.mas_devops.mongodb
```

### Install (AWS DocumentDB)
```yaml
- hosts: localhost
  any_errors_fatal: true
  vars:
    mas_instance_id: masinst1
    mas_config_dir: ~/masconfig
    mongodb_provider: aws
    mongodb_action: provision
    docdb_size: ~/docdb-config.yml
    docdb_cluster_name: test-db
    docdb_ingress_cidr: 10.0.0.0/16
    docdb_egress_cidr: 10.0.0.0/16
    docdb_cidr_az1: 10.0.0.0/26
    docdb_cidr_az2: 10.0.0.64/26
    docdb_cidr_az3: 10.0.0.128/26
    docdb_instance_identifier_prefix: test-db-instance
    vpc_id: test-vpc-id
    aws_access_key_id: aws-key
    aws_secret_access_key: aws-access-key

  roles:
    - ibm.mas_devops.mongodb
```

### AWS DocumentDb Secret Rotation
```yaml
- hosts: localhost
  any_errors_fatal: true
  vars:
    mas_instance_id: masinst1
    mas_config_dir: ~/masconfig
    mongodb_provider: aws
    mongodb_action: docdb_secret_rotate
    docdb_mongo_instance_name: test-db-instance
    db_host: aws.test1.host7283-*****
    db_port: 27017
    docdb_master_username: admin
    docdb_master_password: pass***
    docdb_instance_password_old: oldpass****
    docdb_instance_username: testuser
    aws_access_key_id: aws-key
    aws_secret_access_key: aws-access-key

  roles:
    - ibm.mas_devops.mongodb
```

### Restore (MongoDB Atlas)
```yaml
- hosts: localhost
  any_errors_fatal: true
  vars:
    mongodb_provider: atlas
    mongodb_action: restore-database
    atlas_backup_archive_path: /path/to/mongodb-backup-20240621.tar.gz
    atlas_index_file_path: /path/to/mongodb-indexes-20240621.json
    atlas_mongodb_host: cluster0.abc123.mongodb.net
    atlas_mongodb_username: admin
    atlas_mongodb_password: "{{ lookup('env', 'ATLAS_DB_PASSWORD') }}"
  roles:
    - ibm.mas_devops.mongodb
```
```

### Backup (AWS DocumentDB)

This example demonstrates how to backup an AWS DocumentDB cluster. The backup creates two files:
- `mongodb-backup.tar.gz` - Compressed database backup
- `collection-indexes.json` - Collection indexes for restore

```yaml
- hosts: localhost
  any_errors_fatal: true
  vars:
    mongodb_provider: aws
    mongodb_action: backup-database
    docdb_cluster_name: massre-mas-cluster-8-mongo.cluster-cvwxreialrtj.us-east-1.docdb.amazonaws.com
    docdb_master_username: masinst_inst04
    docdb_master_password: "{{ lookup('env', 'DOCDB_MASTER_PASSWORD') }}"
    docdb_port: 27017
    aws_region: us-east-1
  roles:
    - ibm.mas_devops.mongodb
```

**Command Line Example:**
```bash
ansible-playbook ibm/mas_devops/playbooks/docdb_backup_simple.yml \
  -e "docdb_cluster_name=massre-mas-cluster-8-mongo.cluster-cvwxreialrtj.us-east-1.docdb.amazonaws.com" \
  -e "docdb_master_username=masinst_inst04" \
  -e "docdb_master_password=fn9Uh5wZ4KsZy4OZ0OXx" \
  -e "aws_region=us-east-1" \
  -e "mongodb_provider=aws" \
  -e "mongodb_action=backup-database" \
  -e "docdb_port=27017"
```

**Backup Output:**
The backup process creates the following files in `/tmp/docdb-backup-<timestamp>/`:
- `mongodb-backup.tar.gz` - Full database backup (compressed)
- `collection-indexes.json` - Collection indexes metadata

**Important Notes:**
- The backup does NOT upload to S3 automatically 
- Both files are created locally in the backup directory
- Temporary files (logs, scripts, CA certificates) are automatically cleaned up after backup
- The backup uses `mongodump` with TLS/SSL connection to DocumentDB
- Collection indexes are extracted separately for easier restore operations

**Required Variables:**
- `docdb_cluster_name` - DocumentDB cluster endpoint
- `docdb_master_username` - Admin username
- `docdb_master_password` - Admin password (use environment variable or vault)
- `aws_region` - AWS region where DocumentDB is deployed
- `mongodb_provider` - Must be set to `aws`
- `mongodb_action` - Must be set to `backup-database` or `backup`

**Optional Variables:**
- `docdb_port` - DocumentDB port (default: 27017)
- `docdb_backup_dir` - Custom backup directory (default: `/tmp/docdb-backup-<timestamp>`)
- `docdb_ca_cert_url` - Custom CA certificate URL (default: AWS global bundle)


### AWS DocumentDb destroy-data action

```yaml
- hosts: localhost
  any_errors_fatal: true
  vars:
    mas_instance_id: masinst1
    mongodb_provider: aws
    mongodb_action: destroy-data
    mongo_username: pqradmin
    mongo_password: xyzabc
    config:
      configDb: admin
      authMechanism: DEFAULT
      retryWrites: false
      hosts:
        - host: abc-0.pqr.databases.appdomain.cloud
          port: 32250
        - host: abc-1.pqr.databases.appdomain.cloud
          port: 32250
        - host: abc-2.pqr.databases.appdomain.cloud
          port: 32250
    certificates:
      - alias: ca
        crt: |
          -----BEGIN CERTIFICATE-----
          MIIDDzCCAfegAwIBAgIJANEH58y2/kzHMA0GCSqGSIb3DQEBCwUAMB4xHDAaBgNV
          BAMME0lCTSBDbG91ZCBEYXRhYmFzZXMwHhcNMTgwNjI1MTQyOTAwWhcNMjgwNjIy
          MTQyOTAwWjAeMRwwGgYDVQQDDBNJQk0gQ2xvdWQgRGF0YWJhc2VzMIIBIjANBgkq
          1eKI2FLzYKpoKBe5rcnrM7nHgNc/nCdEs5JecHb1dHv1QfPm6pzIxwIDAQABo1Aw
          TjAdBgNVHQ4EFgQUK3+XZo1wyKs+DEoYXbHruwSpXjgwHwYDVR0jBBgwFoAUK3+X
          Zo1wyKs+DEoYXbHruwSpXjgwDAYDVR0TBAUwAwEB/zANBgkqhkiG9w0BAQsFAAOC
          doqqgGIZ2nxCkp5/FXxF/TMb55vteTQwfgBy60jVVkbF7eVOWCv0KaNHPF5hrqbN
          i+3XjJ7/peF3xMvTMoy35DcT3E2ZeSVjouZs15O90kI3k2daS2OHJABW0vSj4nLz
          +PQzp/B9cQmOO8dCe049Q3oaUA==
          -----END CERTIFICATE-----
  roles:
    - ibm.mas_devops.mongodb

```

## Run Role Playbook

```bash
export MONGODB_STORAGE_CLASS=ibmc-block-gold
export MAS_INSTANCE_ID=masinst1
export MAS_CONFIG_DIR=~/masconfig
ansible-playbook ibm.mas_devops.run_role
```

## Troubleshooting

!!! important
    Please be cautious while performing any of the troubleshooting steps outlined below. It is important to understand that the MongoDB Community operator persists data within Persistent Volume Claims. These claims should not be removed inadvertent deletion of the `mongoce` namespace could result in data loss.

### MongoDB Replica Set Pods Will Not Start

MongoDB 5 has introduced new platform specific requirements. Please consult the [Platform Support Notes](https://www.mongodb.com/docs/manual/administration/production-notes/#x86_64) for detailed information.

It is of particular importance to confirm that the AVX instruction set is exposed or available to the MongoDB workloads. This can easily be determined by entering any running pod on the same OpenShift cluster where MongoDB replica set members are failing to start. Once inside of a running pod the following command can be executed to confirm if the AVX instruction set is available:

```bash
cat /proc/cpuinfo | grep flags | grep avx
```

If `avx` is not found in the available `flags` then either the physical processor hosting the OpenShift cluster does not provide the AVX instruction set or the virtual host configuration is not exposing the AVX instruction set. If the latter is suspected the virtual hosting documentation should be referenced for details on how to expose the AVX instruction set.

### LDAP Authentication

If authenticating via LDAP with PLAIN specified for `authMechanism` then `configDb` must be set to `$external` in the MongoCfg. The field `configDb` in the MongoCfg refers to the authentication database.

### CA Certificate Renewal

!!! warning
    If the MongoDB CA Certificate expires the MongoDB replica set will become unusable. Replica set members will not be able to communicate with each other and client applications (i.e. Maximo Application Suite components) will not be to connect.


In order to renew the CA Certificate used by the MongoDB replica set the following steps must be taken:

- Delete the CA Certificate resource
- Delete the MongoDB server Certificate resource
- Delete the Secrets resources associated with both the CA Certificate and Server Certificate
- Delete the Secret resource which contains the MongoDB configuration parameters
- Delete the ConfigMap resources which contains the CA certificate
- Delete the Secret resource which contains the sever certificate and private key

The following steps illustrate the process required to renew the CA Certificate, sever certificate and reconfigure the MongoDB replica set with the new CA and server certificates.

The first step is to stop the Mongo replica set and MongoDb CE Operator pod.

```bash
oc project mongoce
oc delete deployment mongodb-kubernetes-operator
```

!!! important
    Make sure the MongoDB Community operator pod has terminated before proceeding.


```bash
oc delete statefulset mas-mongo-ce

```

!!! important
    Make sure all pods in the `mongoce` namespace have terminated before proceeding


Remove expired CA Certificate and Server Certificate resources. Clean up MongoDB Community configuration and then run the `mongodb` role.

```bash
oc delete certificate mongo-ca-crt
oc delete certificate mongo-server
oc delete secret mongo-ca-secret
oc delete secret mongo-server-cert

oc delete secret mas-mongo-ce-config
oc delete configmap  mas-mongo-ce-cert-map
oc delete secret mas-mongo-ce-server-certificate-key

export ROLE_NAME=mongodb
ansible-playbook ibm.mas_devops.run_role
```

Once the `mongodb` role has completed the MongoDb CE Operator pod and Mongo replica set should be configured.

After the CA and server Certificates have been renewed you must ensure that that MongoCfg Suite CR is updated with the new CA Certificate. First obtain the CA Certificate from the Secret resource `mongo-ca-secret`. Then edit the Suite MongoCfg CR in the Maximo Application Suite core namespace. This is done by updating the appropriate certificate under `.spec.certificates` in the MongoCfg CR:

```yaml
  spec:
    certificates:
    - alias: ca
      crt: |
        -----BEGIN CERTIFICATE-----

        -----END CERTIFICATE-----

```

If an IBM Suite Licensing Service (SLS) is also connecting to the MongoDB replica set the LicenseService CR must also be updated to reflect the new MongoDB CA. This can be added to the `.spec.mongo.certificates` section of the LicenseService CR.

```yaml
    mongo:
      certificates:
      - alias: mongoca
        crt: |
          -----BEGIN CERTIFICATE-----

          -----END CERTIFICATE-----
```

Once the CA certificate has been updated for the MongoCfg and LicenseService CRs several pods in the core and SLS namespaces might need to be restarted to pick up the changes. This would include but is not limited to coreidp, coreapi, api-licensing.


## License

EPL-2.0
