install_digest_cm
=================

TODO: Write me!
